/*
 * rc_input.h
 *
 *  Created on: Jun 29, 2025
 *      Author: _TTTXN
 */

#ifndef INC_RC_INPUT_H_
#define INC_RC_INPUT_H_

#include "main.h"
#include "tim.h"
#include <stdbool.h>

extern volatile uint32_t rc_rise_time[3];       // สำหรับ TIM_CHANNEL_2/3/4
extern volatile uint32_t rc_pulse_width[3] ;  // ค่า default ~ 1500 us (center)
extern volatile bool rc_capturing[3];



void input_init(void);
float rc_us_to_normalized(uint32_t pulse_us);
float rc_us_to_angle(uint32_t pulse_us, float max_angle_deg);

#endif /* INC_RC_INPUT_H_ */
