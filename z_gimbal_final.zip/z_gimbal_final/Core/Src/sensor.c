/*
 * sensor.c
 *
 *  Created on: Jun 1, 2025
 *      Author: _TTTXN
 */

#include "sensor.h"



float gyro_scale_factor ;
float accel_scale_factor;
float a_x,a_y,a_z,w_x,w_y,w_z;
static uint8_t fifo_buf[FIFO_PACKET_SIZE * FIFO_MAX_PACKETS];
axises  accel_buf[FIFO_MAX_PKG];
axises  gyro_buf[FIFO_MAX_PKG];
uint8_t temp_buf[FIFO_MAX_PKG];
uint16_t ts_buf[FIFO_MAX_PKG];
uint16_t pkt_cnt;	//size of data
axises g_out,a_out;
rpy_t accel_raw,gyro_raw;


Calib_t gyro_offset,accel_offset;
volatile uint8_t idx,gyroIdx   = 0;
volatile uint8_t startCalibration,startGyroCalib = 0;
volatile int accelIdx = -1;  // -1 = ยังไม่เริ่ม, 0–5 = position, ≥6 = เสร็จ


Kalman_t KalmanX = {
        .Q_angle = 0.001f,
        .Q_bias = 0.003f,
        .R_measure = 0.03f
};

Kalman_t KalmanY = {
        .Q_angle = 0.001f,
        .Q_bias = 0.003f,
        .R_measure = 0.03f,
};
Kalman_t KalmanZ = {
        .Q_angle = 0.001f,
        .Q_bias = 0.003f,
        .R_measure = 0.03f,
};

//static function



static float Kalman_getAngle(Kalman_t *Kalman, float newAngle, float newRate, float dt) {
	float rate = newRate - Kalman->bias;
    Kalman->angle += dt * rate;

    Kalman->P[0][0] += dt * (dt * Kalman->P[1][1] - Kalman->P[0][1] - Kalman->P[1][0] + Kalman->Q_angle);
    Kalman->P[0][1] -= dt * Kalman->P[1][1];
    Kalman->P[1][0] -= dt * Kalman->P[1][1];
    Kalman->P[1][1] += Kalman->Q_bias * dt;

    float S = Kalman->P[0][0] + Kalman->R_measure;
    float K[2];
    K[0] = Kalman->P[0][0] / S;
    K[1] = Kalman->P[1][0] / S;

    float y = newAngle - Kalman->angle;
    Kalman->angle += K[0] * y;
    Kalman->bias += K[1] * y;

    float P00_temp = Kalman->P[0][0];
    float P01_temp = Kalman->P[0][1];

    Kalman->P[0][0] -= K[0] * P00_temp;
    Kalman->P[0][1] -= K[0] * P01_temp;
    Kalman->P[1][0] -= K[1] * P00_temp;
    Kalman->P[1][1] -= K[1] * P01_temp;

    return Kalman->angle;
}



//config funtion

HAL_StatusTypeDef  select_user_bank(userbank ub)
{
	HAL_StatusTypeDef status ;
	    uint8_t retry = 0;

	    // ลองส่งคำสั่งไปที่ I2C หลายๆ ครั้งหากมีข้อผิดพลาด
	    while (retry < MAX_RETRY_COUNT) {
	        status = ICM40609_WriteRegister(REG_BANK_SEL, ub);

	        if (status == HAL_OK) {
	            // ถ้าสำเร็จ ก็ออกจากลูป
	            break;
	        } else {
	            retry++;
	            HAL_Delay(10);  // หน่วงเวลาเล็กน้อยก่อนลองใหม่
	        }
	    }

	    if (status != HAL_OK) {
	        // ถ้าหลังจากลองหลายๆ ครั้งแล้วยังไม่สำเร็จ
	        return status;  // คืนค่าข้อผิดพลาด
	    }

	    // หน่วงเวลา 1ms หลังจากตั้งค่าเสร็จ
	    HAL_Delay(1);
	    return HAL_OK;
}

HAL_StatusTypeDef configuration(uint8_t ub, uint8_t reg_address, uint8_t value)
{

	 // เรียก select_user_bank() เพื่อเลือก bank และตรวจสอบผลการทำงาน
	    HAL_StatusTypeDef status = select_user_bank(ub);
	    if (status != HAL_OK) {
	        return status;  // ถ้ามีข้อผิดพลาดในการเลือก bank, คืนค่าผลลัพธ์
	    }
	    uint8_t retry = 0;
	    while (retry < MAX_RETRY_COUNT) {
	    // เขียนค่าลงใน register ตามที่ระบุ
	    status = ICM40609_WriteRegister(reg_address, value);
	    if (status == HAL_OK)  break;
	       retry++;
	       HAL_Delay(10);  // หน่วงเวลาเล็กน้อยก่อนลองใหม่
	     }
	    return status;  // คืนค่าผลลัพธ์จากการเขียนค่า

}

HAL_StatusTypeDef ICM40609_CheckConection(void)
{
	uint8_t who_am_i = 0;
	HAL_StatusTypeDef status;

	status = ICM40609_ReadRegister(ub_0,WHO_AM_I_REG,1,&who_am_i);
	if(status != HAL_OK){
		return status;
	}
	return(who_am_i == 0x3B)? HAL_OK : HAL_ERROR ;

}


HAL_StatusTypeDef  ICM40609_WriteRegister(uint8_t reg, uint8_t data)
{

	uint8_t buffer[2] = {reg,data};
	HAL_StatusTypeDef status;
	uint8_t retry = 0;
	while (retry < MAX_RETRY_COUNT){
		status =  HAL_I2C_Master_Transmit(I2C_HANDLE, ICM40609_ADDRESS << 1, buffer, 2, 100);
		if(status == HAL_OK)break;
		retry++;
		HAL_Delay(10);
	}
	if (status != HAL_OK) return HAL_ERROR;
	return HAL_OK;
}

HAL_StatusTypeDef ICM40609_ReadRegister(uint8_t ub, uint8_t reg, uint8_t len, uint8_t* pdata)
{
    HAL_StatusTypeDef status = select_user_bank(ub);
    if (status != HAL_OK) return status;

    // Transmit register address
    status = HAL_I2C_Master_Transmit(I2C_HANDLE, ICM40609_ADDRESS << 1, &reg, 1, 10);
    if (status != HAL_OK) return status;

    // Receive data
    status = HAL_I2C_Master_Receive(I2C_HANDLE, (ICM40609_ADDRESS << 1) | 0x01, pdata, len, 10);

    return status;
}





//apply function

HAL_StatusTypeDef ICM40609_Init(void)
{

	HAL_StatusTypeDef status;
	status = ICM40609_CheckConection();
	if(status != HAL_OK)return status;

	status = configuration(ub_0, DEVICE_CONFIG,DEVICE_RESET);
	if(status != HAL_OK)return status;
	HAL_Delay(2);

	status =  configuration(ub_0, DRIVE_CONFIG, DRIVE_DEFAUL);
	if(status != HAL_OK)return status;

	status = configuration(ub_0,INT_CONFIG, INT_CONFIG_VALUE);
	if(status != HAL_OK) return status;



	status = configuration(ub_0, PWR_MGMT0, PWR_MGMT0_VALUE);
	if(status != HAL_OK) return status;
	HAL_Delay(50);

	status = configuration(ub_0,GYRO_CONFIG0, GYRO_CONFIG0_VALUE);
	if(status != HAL_OK) return status;

	status = configuration(ub_0, ACCEL_CONFIG0, ACCEL_CONFIG0_VALUE);
	if(status != HAL_OK) return status;


	//===================================== Filter ==================================//


	    // === 1) ตั้งค่า Anti-Aliasing Filter (Bank 1) ===
	//    status = configuration(ub_0, REG_BANK_SEL, 0x01);  // เลือก User Bank 1 :contentReference[oaicite:0]{index=0}
	//    if (status != HAL_OK) return status;

	    /*-----------------------low pass----------------*/
	    status = configuration(ub_1, GYRO_CONFIG_STATIC2, 0x01);            // GYRO_AAF_DIS=0 (enable AAF), GYRO_NF_DIS=1 :contentReference[oaicite:1]{index=1}:contentReference[oaicite:2]{index=2}
	    if (status != HAL_OK) return status;
	    status = configuration(ub_1, GYRO_CONFIG_STATIC3, DESIRED_AAF_DELT);  // ตัวย่อยแบนด์วิดท์ AAF :contentReference[oaicite:3]{index=3}:contentReference[oaicite:4]{index=4}
	    if (status != HAL_OK) return status;
	    status = configuration(ub_1, GYRO_CONFIG_STATIC4, DESIRED_AAF_DELTSQR_LOW);
	    if (status != HAL_OK) return status;
	    status = configuration(ub_1, GYRO_CONFIG_STATIC5,  (DESIRED_AAF_BITSHIFT << 4) | (DESIRED_AAF_DELTSQR_HIGH));
	    if (status != HAL_OK) return status;
	    /*-----------------------end low pass----------------*/

	    // === 1.5) ตั้งค่า Notch Filter (Bank 1) ===

	/*
	 * motor = 50KV,14poles,12V
	 *
	 * Mechanical speed:  		Fm = (KV*V)/60  = (50*12)/60 = 10Hz
	 * Electrical frequency:	Fe = POLE_PAIRS * Fm = 7 * 10 = 70Hz
	 *
	 * so F(desired) = 70 Hz (not support)
	 * from data sheet page 24
	 * “fdesired is the desired frequency of the Notch Filter in kHz.
	 * The lower bound for fdesired is 1 kHz, and the upper bound is 3 kHz.
	 * Operating the notch filter outside this range is not supported.”
	 *
	 * --------------------------------------------------------------------------
	 *  // กำหนด Center Frequency (COSWZ) สำหรับแกน X/Y/Z
	    status = configuration(ub_0, GYRO_CONFIG_STATIC6, COSWZ_LO);  // X_COSWZ[7:0]
	    if (status != HAL_OK) return status;
	    status = configuration(ub_0, GYRO_CONFIG_STATIC7, COSWZ_LO);  // Y_COSWZ[7:0]
	    if (status != HAL_OK) return status;
	    status = configuration(ub_0, GYRO_CONFIG_STATIC8, COSWZ_LO);  // Z_COSWZ[7:0]
	    if (status != HAL_OK) return status;

	    // บิตสูงของ COSWZ + เลือกใช้งานบิตนี้
	    status = configuration(ub_0, GYRO_CONFIG_STATIC9,
	        (1<<3)|(1<<4)|(1<<5)        // เปิดใช้ COSWZ[8] สำหรับ X/Y/Z
	      |  COSWZ_HI                  // COSWZ[8]
	    );
	    if (status != HAL_OK) return status;

	    // ตั้ง bandwidth ของ Notch Filter
	    status = configuration(ub_0, GYRO_CONFIG_STATIC10,
	        (GYRO_NF_BW_SEL << 4)      // bits 6:4 = เลือกความกว้าง notch
	      | (GYRO_HPF_BW_IND << 1)     // (ถ้าใช้ HPF) bits 3:1
	      |  GYRO_HPF_ORD_IND          // bit 0 = เลือก order HPF
	    );
	    if (status != HAL_OK) return status;

	    */

	    /*-----------------------end notch----------------*/


	    /*-----------------------HIGH pass filter----------------*/
	    status = configuration(ub_1, GYRO_CONFIG_STATIC10, ((GYRO_NF_BW_SEL << 4) | GYRO_HPF_BW_IND<<1)|GYRO_HPF_ORD_IND);
	    if (status != HAL_OK) return status;

	    /*-----------------------END HIGH pass filter----------------*/


	//    status = configuration(ub_0, REG_BANK_SEL, 0x00);  // กลับไป Bank 0 :contentReference[oaicite:5]{index=5}:contentReference[oaicite:6]{index=6}
	//    if (status != HAL_OK) return status;

	    // === 2) ตั้งค่า UI Digital Filter (Bank 0) ===

	    status = configuration(ub_0, GYRO_CONFIG1,
	    	    (DEFAULT_TEMP_FILT_BW << 5)    // bits 7:5
	    	  | (GYRO_UI_FILT_ORD     << 2)    // bits 3:2
	    	  | (GYRO_DEC2_M2_ORD     << 0));  // bit 0 = DEC2_M2
	    if (status != HAL_OK) return status;

	    status = configuration(ub_0, GYRO_ACCEL_CONFIG0,
	        (ACCEL_UI_FILT_BW<<4)   // กรอง accel :contentReference[oaicite:9]{index=9}:contentReference[oaicite:10]{index=10}
	      | (GYRO_UI_FILT_BW)      // กรอง gyro
	    );
	    if (status != HAL_OK) return status;


	    status = configuration(ub_0, ACCEL_CONFIG1,
	    		  	(ACCEL_UI_FILT_ORD	<< 3)
				|	(ACCEL_DEC2_M2_ORD 	<< 1));
	    if (status != HAL_OK) return status;

		/*============================FIFO=======================================*/

		// 1) Flush FIFO เก่า
		status = configuration(ub_0, SIGNAL_PART_RESET, SIGNAL_PART_RESET_VALUE);
		if(status != HAL_OK) return status;

		// 2) ตั้ง FIFO mode → Stream-to-FIFO
		status = configuration(ub_0, FIFO_CONFIG, FIFO_CONFIG_VALUE);
		if(status != HAL_OK) return status;

		// 3) เลือก Packet-3 + WM interrupt
		status = configuration(ub_0, FIFO_CONFIG1, FIFO_CONFIG1_VALUE);
		if(status != HAL_OK) return status;

		// 4) ตั้ง Watermark level
		status = configuration(ub_0, FIFO_CONFIG2,(uint8_t)(WM_BYTES & 0xFF));
		if(status != HAL_OK) return status;
		status = configuration(ub_0, FIFO_CONFIG3, (uint8_t)((WM_BYTES >> 8) & 0x0F));
		if(status != HAL_OK) return status;

		// 5) เปิด Record-Count Mode (COUNTL รายงานจำนวน packet แทน byte)
		status = configuration(ub_0, INTF_CONFIG0, INTF_CONFIG0_RC_MODE);
		if (status != HAL_OK) return status;

		// 6) ตั้ง interrupt pin & source
		status = configuration(ub_0,INT_CONFIG, INT_CONFIG_VALUE);
		if(status != HAL_OK) return status;

		status = configuration(ub_0,INT_SOURCE0, INT_SOURCE0_VALUE);
		if(status != HAL_OK) return status;

		/*===========================================================================*/

		status = icm40609_gyro_full_scale_select(_2000dps);
		if(status != HAL_OK) return status;

		status = icm40609_accel_full_scale_select(_32g);
		if(status != HAL_OK)return status;

		status = configuration(ub_1, SENSOR_CONFIG0, SENSER_CONFIG0_GYRO);
		if(status != HAL_OK)return status;

		return HAL_OK;



	}

HAL_StatusTypeDef icm40609_gyro_full_scale_select(gyro_full_scale full_scale)
{
	HAL_StatusTypeDef status;
	uint8_t new_val;

	status = ICM40609_ReadRegister(ub_0, GYRO_CONFIG0,1, &new_val);
	if (status != HAL_OK) return status;

	new_val &= ~GYRO_FS_MASK;  //clear bits 5-7  0xE0 = 1110 0000
		switch(full_scale)
		{
			case _2000dps :
				new_val |= (0x00 << 5); //0000 0000
				gyro_scale_factor = 16.4;
				break;
			case _1000dps :
				new_val |= (0x01 << 5); //0010 0000
				gyro_scale_factor = 32.8;
				break;
			case _500dps :
				new_val |= (0x02 << 5 ); // 0100 0000
				gyro_scale_factor = 65.5;
				break;
			case _250dps :
				new_val |= (0x03 << 5); // 0110 0000
				gyro_scale_factor = 131.0;
				break;
			case _125dps :
				new_val |= (0x04 << 5); //1000 0000
				gyro_scale_factor = 262.0;
				break;
			case _65_5dps :
				new_val |= (0x05 << 5);// 1010 0000
				gyro_scale_factor = 524.3;
				break;
			case _31_25dps :
				new_val |= (0x06 << 5);//1100 0000
				gyro_scale_factor = 1048.6;
				break;
			case _15_625dps :
				new_val |= (0x07 << 5); //1110 0000
				gyro_scale_factor = 2097.2;
				break;

			default:
				return HAL_ERROR;
		}

		status = configuration(ub_0, GYRO_CONFIG0, new_val);
		return status;
}

HAL_StatusTypeDef icm40609_accel_full_scale_select(accel_full_scale full_scale)
{
	HAL_StatusTypeDef status;
	uint8_t new_vall;

	status = ICM40609_ReadRegister(ub_0,  ACCEL_CONFIG0,1,&new_vall);
	if(status != HAL_OK) return status;

	new_vall &= ~ACCEL_FS_MASK ;
	switch(full_scale)
	{
	case _32g:
		new_vall |= (0x00 <<5);
		accel_scale_factor = 1024.0;
		break;
	case _16g:
		new_vall |= (0x01 << 5);
		accel_scale_factor = 2048.0;
		break;
	case _8g:
		new_vall |= (0x02 << 5);
		accel_scale_factor = 4096.0;
		break;
	case _4g:
		new_vall |= (0x03 << 5);
		accel_scale_factor = 8192.0;
		break;

	default:
		return HAL_ERROR;
	}
	status = configuration(ub_0, ACCEL_CONFIG0, new_vall);
	return status;
}
HAL_StatusTypeDef icm40609_read_gyro(axises* data)
{
	HAL_StatusTypeDef status;
	uint8_t val[6];
	 status = ICM40609_ReadRegister(ub_0, GYRO_DATA_X1,6,val);
	 if(status != HAL_OK)return status;

	 	 int16_t raw_x = (int16_t)(val[0] << 8 | val[1]);
	     int16_t raw_y = (int16_t)(val[2] << 8 | val[3]);
	     int16_t raw_z = (int16_t)(val[4] << 8 | val[5]);

	     data->x = (float)raw_x / gyro_scale_factor;
	     data->y = (float)raw_y / gyro_scale_factor;
	     data->z = (float)raw_z / gyro_scale_factor;

	return status;
}

HAL_StatusTypeDef icm40609_read_accel(axises* data)
{
	HAL_StatusTypeDef status;
	uint8_t accel[6];
	status = ICM40609_ReadRegister(ub_0, ACCEL_DATA_X1,6, accel);
	if(status != HAL_OK)return status;

	int16_t raw_x = (int16_t)(accel[0] << 8 | accel[1]);
	int16_t raw_y = (int16_t)(accel[2] << 8 | accel[3]);
	int16_t raw_z = (int16_t)(accel[4] << 8 | accel[5]);

	data -> x = (float)raw_x / accel_scale_factor;
	data -> y = (float)raw_y / accel_scale_factor;
	data -> z = (float)raw_z / accel_scale_factor;



	return status;
}

float icm40609_read_temperature(void)
{
    uint8_t temp_raw[2];
    int16_t temp_out;

    // อ่าน register 0x1D และ 0x1E
    if (ICM40609_ReadRegister(ub_0, TEMP_DATA1, 2, temp_raw) != HAL_OK)
        return -999.0f; // Error code

    temp_out = (int16_t)((temp_raw[0] << 8) | temp_raw[1]);

    // คำนวณองศาเซลเซียส
    return ((float)temp_out / 128.0f) + 25.0f;
}


HAL_StatusTypeDef icm40609_read_accel_gyro(axises* accel, axises* gyro)
{
    HAL_StatusTypeDef status;
    uint8_t data[12];

    // Burst read ตั้งแต่ ACCEL_DATA_X1 (0x1F) → GYRO_DATA_Z0 (0x2A)
    status = ICM40609_ReadRegister(ub_0, ACCEL_DATA_X1, 12, data);
    if (status != HAL_OK) return status;

    // ACCEL (6 bytes)
    int16_t ax = (int16_t)((data[0] << 8) | data[1]);
    int16_t ay = (int16_t)((data[2] << 8) | data[3]);
    int16_t az = (int16_t)((data[4] << 8) | data[5]);

    accel->x = (float)ax / accel_scale_factor;
    accel->y = (float)ay / accel_scale_factor;
    accel->z = (float)az / accel_scale_factor;

    // GYRO (6 bytes)
    int16_t gx = (int16_t)((data[6] << 8) | data[7]);
    int16_t gy = (int16_t)((data[8] << 8) | data[9]);
    int16_t gz = (int16_t)((data[10] << 8) | data[11]);

    gyro->x = (float)gx / gyro_scale_factor;
    gyro->y = (float)gy / gyro_scale_factor;
    gyro->z = (float)gz / gyro_scale_factor;

    return HAL_OK;
}

HAL_StatusTypeDef icm40609_read_all(axises* accel, axises* gyro, float* temperature)
{
    HAL_StatusTypeDef status;
    uint8_t data[14];

    // Burst read ตั้งแต่ TEMP_DATA1 (0x1D) → GYRO_DATA_Z0 (0x2A)
    status = ICM40609_ReadRegister(ub_0, TEMP_DATA1, 14, data);
    if (status != HAL_OK) return status;

    // TEMP (2 bytes)
    int16_t temp_out = (int16_t)((data[0] << 8) | data[1]);
    *temperature = ((float)temp_out / 128.0f) + 25.0f;

    // ACCEL (6 bytes)
    int16_t ax = (int16_t)((data[2] << 8) | data[3]);
    int16_t ay = (int16_t)((data[4] << 8) | data[5]);
    int16_t az = (int16_t)((data[6] << 8) | data[7]);

    accel->x = (float)ax / accel_scale_factor;
    accel->y = (float)ay / accel_scale_factor;
    accel->z = (float)az / accel_scale_factor;

    // GYRO (6 bytes)
    int16_t gx = (int16_t)((data[8] << 8) | data[9]);
    int16_t gy = (int16_t)((data[10] << 8) | data[11]);
    int16_t gz = (int16_t)((data[12] << 8) | data[13]);

    gyro->x = (float)gx / gyro_scale_factor;
    gyro->y = (float)gy / gyro_scale_factor;
    gyro->z = (float)gz / gyro_scale_factor;

    return HAL_OK;
}

HAL_StatusTypeDef ICM40609_ReadFIFO_Packet3(
    axises*    accel_buf,
    axises*    gyro_buf,
    uint8_t*   temp_buf,
    uint16_t*  ts_buf,
    uint16_t   max_packets,
    uint16_t*  packet_count
) {
    HAL_StatusTypeDef status;
    uint8_t cnt_buf[2];
    uint16_t byte_count, packets;

//    uint8_t  raw_pkts;
//    uint16_t packets;



    // 1) Switch to User Bank 0
    status = select_user_bank(0);
    if (status != HAL_OK) return status;

    // 2) Read FIFO count (FIFO_COUNTH=0x2E, FIFO_COUNTL=0x2F) in one go
    status = HAL_I2C_Mem_Read(
        &hi2c2,
        ICM40609_ADDRESS << 1,
        FIFO_COUNTH,
        I2C_MEMADD_SIZE_8BIT,
        cnt_buf,
        2,          // read two bytes: high+low
        1           // timeout
    );
    if (status != HAL_OK) return status;
    byte_count = ((uint16_t)cnt_buf[0] << 8) | cnt_buf[1];
    packets   = byte_count / FIFO_PACKET_SIZE;


    if (packets == 0) {
        *packet_count = 0;
        return HAL_OK;
    }
    if (packets > max_packets) {
        packets = max_packets;
    }
    uint16_t read_bytes = packets * FIFO_PACKET_SIZE;

    // 3) Burst-read all FIFO data at once
    status = HAL_I2C_Mem_Read(
        &hi2c2,
        ICM40609_ADDRESS << 1 ,
        FIFO_DATA,             // 0x30
        I2C_MEMADD_SIZE_8BIT,
        fifo_buf,
        read_bytes,
        1                      // timeout
    );
    if (status != HAL_OK) return status;


    // 4) Parse each Packet-3
    for (uint16_t i = 0; i < packets; i++) {
        uint8_t *p = &fifo_buf[i * FIFO_PACKET_SIZE];
        uint8_t header = p[0];
        // Skip if invalid packet (HEADER_MSG=1)
        if (header & 0x80) continue;

        // Accel (6 bytes)
        int16_t ax = (p[1]  << 8) | p[2];
        int16_t ay = (p[3]  << 8) | p[4];
        int16_t az = (p[5]  << 8) | p[6];
        accel_buf[i].x = ((float)ax / accel_scale_factor) ;
        accel_buf[i].y = ((float)ay / accel_scale_factor) ;
        accel_buf[i].z = ((float)az / accel_scale_factor) ;

        // Gyro (6 bytes)
        int16_t gx = (p[7]  << 8) | p[8];
        int16_t gy = (p[9]  << 8) | p[10];
        int16_t gz = (p[11] << 8) | p[12];
        gyro_buf[i].x = ((float)gx / gyro_scale_factor) ;
        gyro_buf[i].y = ((float)gy / gyro_scale_factor) ;
        gyro_buf[i].z = ((float)gz / gyro_scale_factor) ;

        // Temperature (1 byte, raw)
        temp_buf[i] = p[13];

        // Timestamp (2 bytes)
        ts_buf[i] = (p[14] << 8) | p[15];
    }

    *packet_count = packets;
    return HAL_OK;
}

//=================================================calibration===========================================================

//accelerometer

/**
 * @param samples       จำนวนตัวอย่างที่จะเฉลี่ย
 * @param readAccel     ฟังก์ชัน pointer สำหรับอ่าน accel 1 sample
 * @param positionIndex ดัชนีตำแหน่ง (0–5)
 *                      0:+X up, 1:-X down, 2:+Y up, 3:-Y down, 4:+Z up, 5:-Z down
 * @param calib         pointer ไปยังโครงสร้าง Accel6Calib_t
 * @return HAL_OK/ERROR
 */
// -------------------------------------------------------------------
HAL_StatusTypeDef Accel6_CalibratePosition(
    uint16_t        samples,
    uint8_t         positionIndex,
    Calib_t  *calib
) {
    if (calib == NULL || samples == 0 || positionIndex > 5) {
        return HAL_ERROR;
    }

    axises accel_tmp, gyro_tmp;
    uint8_t  temp_tmp;
    uint16_t ts_tmp, pkt_cnt;
    float sum_x = 0, sum_y = 0, sum_z = 0;

    for (uint16_t i = 0; i < samples; /* see inside */) {
        if (ICM40609_ReadFIFO_Packet3(&accel_tmp, &gyro_tmp,
                                      &temp_tmp, &ts_tmp,
                                      1, &pkt_cnt) != HAL_OK
            || pkt_cnt == 0)
        {
            continue;   // ไม่เพิ่ม i, อ่านใหม่
        }
        sum_x += accel_tmp.x;
        sum_y += accel_tmp.y;
        sum_z += accel_tmp.z;
        i++;
    }

    calib->avg[positionIndex][0] = sum_x / samples;
    calib->avg[positionIndex][1] = sum_y / samples;
    calib->avg[positionIndex][2] = sum_z / samples;
    calib->lastPosition = positionIndex;
    return HAL_OK;
}

HAL_StatusTypeDef Accel6_ComputeCalibration(Calib_t *calib) {
    if (calib == NULL) {
        return HAL_ERROR;
    }
    // 1) เตรียมข้อมูล Y (3×6) และ U (6×3)
    float Y[3][6];
    const float U[6][3] = {
        { +G_CONST,   0.0f,       0.0f    },  // +X up
        { -G_CONST,   0.0f,       0.0f    },  // -X down
        {  0.0f,    +G_CONST,     0.0f    },  // +Y up
        {  0.0f,    -G_CONST,     0.0f    },  // -Y down
        {  0.0f,      0.0f,    +G_CONST   },  // +Z up
        {  0.0f,      0.0f,    -G_CONST   }   // -Z down
    };
    for (int k = 0; k < 6; k++) {
        Y[0][k] = calib->avg[k][0];
        Y[1][k] = calib->avg[k][1];
        Y[2][k] = calib->avg[k][2];
    }

    // 2) หาค่า bias แต่ละแกน = average ของทุกตำแหน่ง
    float bias[3] = {0};
    for (int ax = 0; ax < 3; ax++) {
        for (int k = 0; k < 6; k++) {
            bias[ax] += Y[ax][k];
        }
        bias[ax] /= 6.0f;
        // store
        if (ax == 0) calib->bias_x = bias[0];
        if (ax == 1) calib->bias_y = bias[1];
        if (ax == 2) calib->bias_z = bias[2];
    }

    // 3) ลบ bias ออกจาก Y → Y0
    float Y0[3][6];
    for (int ax = 0; ax < 3; ax++) {
        for (int k = 0; k < 6; k++) {
            Y0[ax][k] = Y[ax][k] - bias[ax];
        }
    }

    // 4) คำนวณ 3×3 matrix M = Y0·Uᵀ · inv(U·Uᵀ)
    //    แต่เมื่อ U·Uᵀ = 2·G²·I   → inv = (1/(2·G²))·I
    float M[3][3] = {0};
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            float sum = 0;
            for (int k = 0; k < 6; k++) {
                sum += Y0[i][k] * U[k][j];
            }
            M[i][j] = sum / (2.0f * G_CONST * G_CONST);
        }
    }

    // 5) แตก M ออกเป็น scale + misalignment
    //    M = K_a · T_a⁻¹  ซึ่ง K_a คือ scale diagonal, T_a⁻¹ มี off-diagonal = misalignment
    calib->scale_x  = M[0][0];
    calib->mis_xy   = M[0][1];   // effect แกน Y ต่อนแกน X
    calib->mis_xz   = M[0][2];   // effect แกน Z ต่อนแกน X

    calib->mis_yx   = M[1][0];
    calib->scale_y  = M[1][1];
    calib->mis_yz   = M[1][2];

    calib->mis_zx   = M[2][0];
    calib->mis_zy   = M[2][1];
    calib->scale_z  = M[2][2];

    return HAL_OK;
}

void Accel6_ApplyCalibration(
    const Calib_t 		*calib,
    const axises        *raw,     // .x/.y/.z คือค่าดิบ
    axises              *out      // .x/.y/.z คือค่าคาลิเบรต
){
    float x0 = raw->x - calib->bias_x;
    float y0 = raw->y - calib->bias_y;
    float z0 = raw->z - calib->bias_z;

    out->x = calib->scale_x * x0
           + calib->mis_xy   * y0
           + calib->mis_xz   * z0;

    out->y = calib->mis_yx   * x0
           + calib->scale_y  * y0
           + calib->mis_yz   * z0;

    out->z = calib->mis_zx   * x0
           + calib->mis_zy   * y0
           + calib->scale_z  * z0;
}

HAL_StatusTypeDef ICM40609_CalibrateGyroOFFSET(uint16_t samples, Calib_t *gyro_bias)
{
    if (gyro_bias == NULL) {
        return HAL_ERROR;
    }

    axises accel_tmp;
    axises gyro_tmp;
    uint8_t temp_tmp;
    uint16_t ts_tmp;
    uint16_t pkt_cnt;
    float sum_x = 0, sum_y = 0, sum_z = 0;

    for (uint16_t i = 0; i < samples; ) {
        HAL_StatusTypeDef status = ICM40609_ReadFIFO_Packet3(
            &accel_tmp, &gyro_tmp,
            &temp_tmp, &ts_tmp,
            1, &pkt_cnt);
        if (status != HAL_OK) return status;
        if (pkt_cnt == 0) continue;  // ว่างก็วนใหม่

        sum_x += gyro_tmp.x;
        sum_y += gyro_tmp.y;
        sum_z += gyro_tmp.z;
        i += pkt_cnt;
    }

    gyro_bias->bias_x = sum_x / (float)samples;
    gyro_bias->bias_y = sum_y / (float)samples;
    gyro_bias->bias_z = sum_z / (float)samples;

    return HAL_OK;
}

void Gyro_ApplyCalibration(
    const Calib_t     *calib,  // พารามิเตอร์ bias+scale
    const axises      *raw,    // ค่าดิบจาก FIFO (LSB)
    axises            *out     // ค่าชดเชยแล้ว (°/s)
){

    // 1) ลบ bias ทุกแกน
	out->x = raw->x - calib->bias_x;
	out->y = raw->y - calib->bias_y;
	out->z = raw->z - calib->bias_z;



    // 1) ลบ bias ทุกแกน
//    float x0 = raw->x - calib->bias_x;
//    float y0 = raw->y - calib->bias_y;
//    float z0 = raw->z - calib->bias_z;
//
//    // 2) คูณ scale สำหรับแกน X/Y
//    out->x = x0 * calib->scale_x;
//    out->x = y0 * calib->scale_y;
//    out->z = z0 * calib->scale_z;
}


void RunIMUCalibration(void)
{
    memset(&accel_offset, 0, sizeof(accel_offset));
    accel_offset.lastPosition = 0xFF;

    idx = 0;

    // ช่วง calibrate accelerometer
    while (idx < 6) {
        while (!startCalibration) __NOP(); // รอให้ตั้ง flag ว่าพร้อมเริ่มท่าที่ idx
        Accel6_CalibratePosition(CALIB_SAMPLES, idx, &accel_offset);
        idx++;
        startCalibration = 0; // reset flag

        for(int i = 0;i<3;i++){
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);   // เปิดไฟ
            HAL_Delay(300);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET); // ปิดไฟ
            HAL_Delay(300);
        }
    }

    // คำนวณค่าชดเชยของ accelerometer
    Accel6_ComputeCalibration(&accel_offset);

    // รอเริ่มการ calibrate gyroscope
    while (!startGyroCalib) __NOP();
    ICM40609_CalibrateGyroOFFSET(CALIB_SAMPLES, &gyro_offset);
    startGyroCalib = 0; // reset flag
    for(int i = 0;i<3;i++){
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);   // เปิดไฟ
        HAL_Delay(300);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET); // ปิดไฟ
        HAL_Delay(300);
    }
}

/*

 memset() → ใช้ได้ทุก compiler ปลอดภัย
(Calib_t){0} → สะอาด สั้น แต่ต้องใช้ C99+

*/
void reset_cal(void){
    memset(&accel_offset, 0, sizeof(Calib_t));
    memset(&gyro_offset, 0, sizeof(Calib_t));

//    accel_offset = (Calib_t){0};
//    gyro_offset = (Calib_t){0};

    idx = 0;


}

void apply_icm40609(float *a_x, float *a_y, float *a_z, float *w_x, float *w_y, float *w_z){

	 ICM40609_ReadFIFO_Packet3( &accel_buf[0], &gyro_buf[0], temp_buf, ts_buf,FIFO_MAX_PKG, &pkt_cnt);
	 Accel6_ApplyCalibration(&accel_offset, &accel_buf[0], &a_out);
	 Gyro_ApplyCalibration(&gyro_offset, &gyro_buf[0], &g_out);

	 *w_x = g_out.x * DEG2RAD;
	 *w_y = g_out.y * DEG2RAD;
	 *w_z = g_out.z * DEG2RAD;
	 *a_x = a_out.x * DEG2RAD;
	 *a_y = a_out.y * DEG2RAD;
	 *a_z = a_out.z * DEG2RAD;



}

void applyicm40609(axises *accel,axises *gyro){

	 ICM40609_ReadFIFO_Packet3( &accel_buf[0], &gyro_buf[0], temp_buf, ts_buf,FIFO_MAX_PKG, &pkt_cnt);
	 Accel6_ApplyCalibration(&accel_offset, &accel_buf[0], &a_out);
	 Gyro_ApplyCalibration(&gyro_offset, &gyro_buf[0], &g_out);

	 gyro->x = g_out.x * DEG2RAD;
	 gyro->y = g_out.y * DEG2RAD;
	 gyro->z = g_out.z * DEG2RAD;
	 accel->x = a_out.x * DEG2RAD;
	 accel->y = a_out.y * DEG2RAD;
	 accel->z = a_out.z * DEG2RAD;



}


HAL_StatusTypeDef calculate_rpy(axises* accel, axises* gyro, rpy_t* rpy, float dt)
{
    if (accel == NULL || gyro == NULL || rpy == NULL || dt <= 0) {
        return HAL_ERROR; // ตรวจสอบค่า NULL และค่า dt ที่ผิดพลาด
    }

       // 1) คำนวณ Roll/Pitch จาก Accelerometer ด้วย atan2f
       float accel_roll = atan2f(accel->y, accel->z)
                          * RAD2DEG;
       float accel_pitch = atan2f(
                               -accel->x,
                               sqrtf(accel->y * accel->y + accel->z * accel->z)
                           ) * RAD2DEG;


       // 🔹 ป้องกันการกลับด้านของแกน X เมื่ออุปกรณ์กลับหัว
       if (fabs(accel_pitch) > 90.0f) {
           accel_roll = -accel_roll; // กลับค่า Roll เมื่อ Pitch > 90° หรือ < -90°
       }
       rpy->roll  = Kalman_getAngle(&KalmanX, accel_roll, gyro->x, dt);
       rpy->pitch = Kalman_getAngle(&KalmanY, accel_pitch, gyro->y, dt);


       // 🔹 ป้องกันการกลับด้านของแกน X อีกครั้งในขั้นตอนสุดท้าย
//       if (fabs(rpy->pitch) > 90.0f) {
//           rpy->roll = -rpy->roll;
//       }

       // คำนวณ Yaw จาก Gyroscope
       static float yaw = 0;
       yaw += (gyro -> z ) * dt;

              if (yaw > 180.0f) yaw -= 360.0f;
              if (yaw < -180.0f) yaw += 360.0f;
       rpy ->yaw = yaw;



    return HAL_OK;
}



