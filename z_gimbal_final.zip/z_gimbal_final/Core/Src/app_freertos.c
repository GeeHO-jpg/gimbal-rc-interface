/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usb_device.h"
#include "app.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
volatile uint8_t system_initialized = 0;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
uint8_t dataRead[100];

uint8_t dataWrite[100];

char *dataW = "Hello World";
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for imu */
osThreadId_t imuHandle;
const osThreadAttr_t imu_attributes = {
  .name = "imu",
  .priority = (osPriority_t) osPriorityRealtime,
  .stack_size = 128 * 4
};
/* Definitions for roll */
osThreadId_t rollHandle;
const osThreadAttr_t roll_attributes = {
  .name = "roll",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4
};
/* Definitions for pitch */
osThreadId_t pitchHandle;
const osThreadAttr_t pitch_attributes = {
  .name = "pitch",
  .priority = (osPriority_t) osPriorityNormal1,
  .stack_size = 128 * 4
};
/* Definitions for yaw */
osThreadId_t yawHandle;
const osThreadAttr_t yaw_attributes = {
  .name = "yaw",
  .priority = (osPriority_t) osPriorityNormal2,
  .stack_size = 128 * 4
};
/* Definitions for eeprom */
osThreadId_t eepromHandle;
const osThreadAttr_t eeprom_attributes = {
  .name = "eeprom",
  .priority = (osPriority_t) osPriorityLow,
  .stack_size = 256 * 4
};
/* Definitions for imuMutex */
osMutexId_t imuMutexHandle;
const osMutexAttr_t imuMutex_attributes = {
  .name = "imuMutex"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void imuTask(void *argument);
void rollTask(void *argument);
void pitchTask(void *argument);
void yawTask(void *argument);
void eepromTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */
  /* Create the mutex(es) */
  /* creation of imuMutex */
  imuMutexHandle = osMutexNew(&imuMutex_attributes);

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of imu */
  imuHandle = osThreadNew(imuTask, NULL, &imu_attributes);

  /* creation of roll */
  rollHandle = osThreadNew(rollTask, NULL, &roll_attributes);

  /* creation of pitch */
  pitchHandle = osThreadNew(pitchTask, NULL, &pitch_attributes);

  /* creation of yaw */
  yawHandle = osThreadNew(yawTask, NULL, &yaw_attributes);

  /* creation of eeprom */
  eepromHandle = osThreadNew(eepromTask, NULL, &eeprom_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_imuTask */
/**
  * @brief  Function implementing the imu thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_imuTask */
void imuTask(void *argument)
{
  /* init code for USB_Device */
  //MX_USB_Device_Init();
  /* USER CODE BEGIN imuTask */
  /* Infinite loop */
//  osEventFlagsWait(myEvent01Handle, 0x01, osFlagsWaitAll, osWaitForever);
  for(;;)
  {
	  osMutexAcquire(imuMutexHandle, osWaitForever);
	  get_imu();
//	  HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_9);
	  osMutexRelease(imuMutexHandle);
    osDelay(1);
  }
  /* USER CODE END imuTask */
}

/* USER CODE BEGIN Header_rollTask */
/**
* @brief Function implementing the roll thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_rollTask */
void rollTask(void *argument)
{
  /* USER CODE BEGIN rollTask */
  /* Infinite loop */
//	osEventFlagsWait(myEvent01Handle, 0x01, osFlagsWaitAll, osWaitForever);
  for(;;)
  {
	  osMutexAcquire(imuMutexHandle, osWaitForever);
	  control_roll();
//	  control_motor(roll_rpm , dt, &roll_motor, &tim_roll_a, roll_a, &tim_roll_b, roll_b, &tim_roll_c, roll_c);
//	  HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_8);
	  osMutexRelease(imuMutexHandle);
    osDelay(1);
  }
  /* USER CODE END rollTask */
}

/* USER CODE BEGIN Header_pitchTask */
/**
* @brief Function implementing the pitch thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_pitchTask */
void pitchTask(void *argument)
{
  /* USER CODE BEGIN pitchTask */
  /* Infinite loop */
//	osEventFlagsWait(myEvent01Handle, 0x01, osFlagsWaitAll, osWaitForever);
  for(;;)
  {
	  osMutexAcquire(imuMutexHandle, osWaitForever);
	  control_pitch();
//	  control_motor(pitch_rpm , dt, &pitch_motor, &tim_pitch_a, pitch_a, &tim_pitch_b, pitch_b, &tim_pitch_c, pitch_c);
//	  HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_9);
	  osMutexRelease(imuMutexHandle);
	  osDelay(1);
  }
  /* USER CODE END pitchTask */
}

/* USER CODE BEGIN Header_yawTask */
/**
* @brief Function implementing the yaw thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_yawTask */
void yawTask(void *argument)
{
  /* USER CODE BEGIN yawTask */
  /* Infinite loop */
//	osEventFlagsWait(myEvent01Handle, 0x01, osFlagsWaitAll, osWaitForever);
  for(;;)
  {
	  osMutexAcquire(imuMutexHandle, osWaitForever);
	  control_yaw();
//	  control_motor(yaw_rpm , dt, &yaw_motor, &tim_yaw_a, yaw_a, &tim_yaw_b, yaw_b, &tim_yaw_c, yaw_c);
	  osMutexRelease(imuMutexHandle);
    osDelay(1);
  }
  /* USER CODE END yawTask */
}

/* USER CODE BEGIN Header_eepromTask */
/**
* @brief Function implementing the eeprom thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_eepromTask */
void eepromTask(void *argument)
{
  /* USER CODE BEGIN eepromTask */
  /* Infinite loop */
  for(;;)
  {
	    if (write_eeprom_requested) {
	      write_eeprom_requested = 0;

	    // ✅ รอ flag จาก USBTask
//	    osEventFlagsWait(myEvent01Handle, 0x02, osFlagsWaitAny, osWaitForever);

	    osMutexAcquire(imuMutexHandle, osWaitForever);
	    copy_config_to_struct_eeprom();
	    osMutexRelease(imuMutexHandle);


	    if (osMutexAcquire(imuMutexHandle, EEPROM_TIMEOUT) == osOK)  // 🔐 ล็อกก่อนเขียน
	    {
	        if (EEPROM_Write_Blocking(0, 0, (uint8_t*)&eepromstruct, sizeof(ConfigData_t)) == HAL_OK)
	        {
	            // ✅ Blink LED แสดงว่า save สำเร็จ
	            for (int i = 0; i < 5; i++) {
	                HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);
	                osDelay(100);
	                HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);
	                osDelay(100);
	            }
	        }

	        osMutexRelease(imuMutexHandle);  // 🔓 ปลดล็อกหลังเขียน
	    }
	    }
    osDelay(1);
  }
  /* USER CODE END eepromTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

