/*
 * app.h
 *
 *  Created on: Jun 9, 2025
 *      Author: _TTTXN
 */

#ifndef INC_APP_H_
#define INC_APP_H_

#include "main.h"
#include "filter.h"
#include "pwm.h"
#include "sensor.h"
#include "PID.h"
#include "crc.h"
#include "usbd_cdc_if.h"
#include "packet.h"
#include "rc_input.h"
#include "eeprom.h"
#include "stm32g0xx_it.h"


// -----------------------------------------------------------------------------
// Global Variables
// -----------------------------------------------------------------------------

//#define FIRMWARE_VERSION 2000

/**
 * @brief Structure holding all state variables related to axis control (roll/pitch/yaw)
 *
 * This struct encapsulates the full PID control process:
 *  - target angle and velocity
 *  - actual vs error
 *  - filtered output
 *  - RPM command
 *  - rate (angular velocity)
 */
typedef struct{
	float target_angle;
	float angle_error;
	float target_velocity;
	float velocity_error;
	float output;
	float output_lp;
	float rpm;
	float rate;
}param_axis_t;

/** @brief Roll axis control state */
extern param_axis_t param_roll;
/** @brief Pitch axis control state */
extern param_axis_t param_pitch;
/** @brief Yaw axis control state */
extern param_axis_t param_yaw;
/** @brief PID controllers for roll axis */
extern PID_t roll_inner, roll_outer;
/** @brief PID controllers for pitch axis */
extern PID_t pitch_inner, pitch_outer;
/** @brief PID controllers for yaw axis */
extern PID_t yaw_inner, yaw_outer;
/** @brief Motor driver configuration per axis */
extern AxisControl_t roll_motor, pitch_motor, yaw_motor;
/** @brief Quaternion targets for each axis */
extern quaternion q_target_roll, q_target_pitch, q_target_yaw;



/**
 * @brief  Filtered gyroscope values (Low-Pass Filtered)
 *
 * These are updated in get_imu() and used in the Madgwick filter.
 */
extern float gx_lp, gy_lp, gz_lp;

/**
 * @brief  Orientation angles computed from IMU (degrees)
 *
 * These are computed from the quaternion using the ZYX Euler convention.
 */
//extern float roll, pitch, yaw,yaw_raw,k_p,k_r;

// -----------------------------------------------------------------------------
// Function Prototypes
// -----------------------------------------------------------------------------

/**
 * @brief  Initializes system components (PWM, IMU, Calibration)
 *
 * This function performs:
 *   - Starting PWM channels for motor control
 *   - Initializing the ICM40609 IMU
 *   - Performing calibration of accelerometer and gyroscope
 *
 * @note Call this once in your main() before entering the main control loop.
 *
 * Example:
 *   apply_init();
 */
void apply_init(void);


/**
 * @brief  Reads IMU data and updates roll, pitch, yaw angles
 *
 * This function performs:
 *   - Reading raw IMU data (accelerometer and gyroscope)
 *   - Applying low-pass filtering to gyro data
 *   - Applying Madgwick filter to estimate orientation
 *   - Converting quaternion to Euler angles (ZYX convention)
 *
 * @note Result is stored in global variables: roll, pitch, yaw.
 * @note Call this function periodically (e.g., every control loop)
 *
 * Example:
 *   get_imu();
 */
void get_imu(void);


/**
 * @brief  Controls the motor in open-loop mode using 3-phase PWM
 *
 * @param speed_rpm  Desired speed in RPM
 * @param dt         Time since last call (in seconds)
 * @param param      Pointer to AxisControl_t that contains torque settings
 * @param htimA      Timer handle for Phase A
 * @param chA        Channel for Phase A
 * @param htimB      Timer handle for Phase B
 * @param chB        Channel for Phase B
 * @param htimC      Timer handle for Phase C
 * @param chC        Channel for Phase C
 *
 * This function generates a rotating sine wave pattern to drive BLDC motors
 * using open-loop control.
 *
 * Example:
 *   control_motor(100.0f, 0.01f, &motor_axis,
 *                 &htim1, TIM_CHANNEL_1,
 *                 &htim1, TIM_CHANNEL_2,
 *                 &htim15, TIM_CHANNEL_2);
 */
void control_motor(
    float speed_rpm,
    float dt,
    AxisControl_t *param,
    TIM_HandleTypeDef *htimA, uint32_t chA,
    TIM_HandleTypeDef *htimB, uint32_t chB,
    TIM_HandleTypeDef *htimC, uint32_t chC
);

/**
 * @brief Compute dot product between two 3D vectors
 *
 * @param v1 Pointer to vector 1 (float[3])
 * @param v2 Pointer to vector 2 (float[3])
 * @return Dot product result
 */
float dot_product(const float *v1, const float *v2);


/**
 * @brief Run PID controller computation
 *
 * @param error Current error input
 * @param dt Delta time (seconds)
 * @param pid Pointer to PID parameter struct
 * @return PID output value
 */
float pid(float error, float dt, PID_t *pid);


/**
 * @brief Control loop for Roll axis using quaternion-based nested PID
 */
void control_roll(void);

/**
 * @brief Control loop for Pitch axis using quaternion-based nested PID
 */
void control_pitch(void);

/**
 * @brief Control loop for Yaw axis using quaternion-based nested PID
 */
void control_yaw(void);

/**
 * @brief Copy current config (PID, calibration, motor settings) into EEPROM struct
 */
void copy_config_to_struct_eeprom(void);

/**
 * @brief Load config from EEPROM struct into runtime variables
 */
void load_struct_to_config_from_eeprom(void);


/**
 * @brief Check and reload EEPROM data if the revision number has changed
 *
 * @param page Flash memory page
 * @param offset Offset in bytes from start of page
 */
void check_and_load_if_revision_changed(uint16_t page, uint16_t offset);


/**
 * @brief Save current configuration into flash EEPROM
 *
 * @param page Flash memory page
 * @param offset Offset in bytes from start of page
 */
void save_to_eeprom(uint16_t page, uint16_t offset);


/**
 * @brief Clear all PID internal states (integral and previous error)
 */
void clear_pid_internal_state(void);
#endif /* INC_APP_H_ */
