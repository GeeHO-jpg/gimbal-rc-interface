/*
 * flash.h
 *
 *  Created on: Jun 23, 2025
 *      Author: _TTTXN
 */

#ifndef INC_FLASH_H_
#define INC_FLASH_H_

/**
  ***************************************************************************************************************
  ***************************************************************************************************************
  ***************************************************************************************************************
  File:	      FLASH_PAGE_F1.h
  Modifier:   ControllersTech.com
  Updated:    27th MAY 2021
  ***************************************************************************************************************
  Copyright (C) 2017 ControllersTech.com
  This is a free software under the GNU license, you can redistribute it and/or modify it under the terms
  of the GNU General Public License version 3 as published by the Free Software Foundation.
  This software library is shared with public for educational purposes, without WARRANTY and Author is not liable for any damages caused directly
  or indirectly by this software, read more about this on the GNU General Public License.
  ***************************************************************************************************************
*/



#include "stm32g0xx_hal.h"
#include "string.h"
#include "stdio.h"



#define FLASH_BASE_ADDRESS  0x08000000
#define FLASH_SAVE_ADDR		0x0801F800

typedef struct{
	float bias_x, bias_y, bias_z;
}gyro_t;
typedef struct{
	float accel_offset[6][3];
	gyro_t gyro_offset;
	uint32_t crc;
}flash_t;


extern flash_t save_data;


uint32_t Flash_Write_Data (uint32_t StartPageAddress, uint32_t *Data, uint16_t numberofwords);

void Flash_Read_Data (uint32_t StartPageAddress, uint32_t *RxBuf, uint16_t numberofwords);

void Convert_To_Str (uint32_t *Data, char *Buf);

void Flash_Write_NUM (uint32_t StartSectorAddress, float Num);

float Flash_Read_NUM (uint32_t StartSectorAddress);

void Flash_Erase_Page(uint32_t address);



/********************  FLASH_Error_Codes   ***********************//*
HAL_FLASH_ERROR_NONE      0x00U  // No error
HAL_FLASH_ERROR_PROG      0x01U  // Programming error
HAL_FLASH_ERROR_WRP       0x02U  // Write protection error
HAL_FLASH_ERROR_OPTV      0x04U  // Option validity error
*/




#endif /* INC_FLASH_H_ */
