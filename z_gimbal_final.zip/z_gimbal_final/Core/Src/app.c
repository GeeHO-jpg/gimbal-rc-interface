/*
 * app.c
 *
 *  Created on: Jun 9, 2025
 *      Author: _TTTXN
 */


#include "app.h"


param_axis_t param_roll,param_pitch,param_yaw;

PID_t roll_inner,roll_outer;
PID_t pitch_inner,pitch_outer;
PID_t yaw_inner,yaw_outer;


AxisControl_t roll_motor;
AxisControl_t pitch_motor;
AxisControl_t yaw_motor;

quaternion q_target_roll;
quaternion q_target_pitch;
quaternion q_target_yaw;



float dt =0.001f, dt_t = 0.005f;
//float setpoint_roll,setpoint_pitch,setpoint_yaw,angle_deg;

float gyro_body[3];

// Global variables to store filtered angular velocities
float gx_lp = 0.0f, gy_lp = 0.0f, gz_lp = 0.0f;




float dot_product(const float *v1, const float *v2) {
    return v1[0]*v2[0] + v1[1]*v2[1] + v1[2]*v2[2];
}

/**
 * @brief  Reads IMU data, filters it, and computes orientation angles.
 *
 * This function:
 *   1. Reads raw data from the ICM40609 sensor.
 *   2. Applies a low-pass filter to the gyroscope readings.
 *   3. Uses the Madgwick filter to estimate orientation in quaternion form.
 *   4. Converts quaternion to Euler angles (Roll, Pitch, Yaw).
 *
 * @note Resulting orientation values are stored in global variables: roll, pitch, yaw.
 * @note Call this function in your main loop or periodically in a timer interrupt.
 */
void get_imu(void){
    // 1. อ่านค่า IMU
    apply_icm40609(&a_x, &a_y, &a_z, &w_x, &w_y, &w_z);

    // 2. Low-pass filter สำหรับ gyro
    LP_filter(w_x, w_y, w_z, &gx_lp, &gy_lp, &gz_lp);

    gyro_body[0] = gx_lp;
    gyro_body[1] = gy_lp;
    gyro_body[2] = gz_lp;
    imu_filter(a_x, a_y, a_z,gx_lp, gy_lp, gz_lp);
//    cal_quanternion();

}

/**
 * @brief  Initializes all necessary components: PWM, IMU, and calibration.
 *
 * This function:
 *   - Starts all PWM channels for motor control.
 *   - Initializes the ICM40609 IMU sensor.
 *   - Performs accelerometer and gyroscope calibration.
 *
 * @note Call this function once in your main setup or initialization routine.
 * @warning Make sure the system is stationary during calibration.
 */
void apply_init(void){
	motor_init();          // Initialize and start PWM for all phases
	input_init();			//Initialize input
    ICM40609_Init();      // Initialize IMU
}

/**
 * @brief  Controls the motor in open-loop mode using electrical angle update.
 *
 * @param  speed_rpm     Desired motor speed in RPM.
 * @param  dt            Time since last update (in seconds).
 * @param  param         Pointer to AxisControl_t containing torque settings.
 * @param  htimA–C       TIM handles for phases A, B, and C.
 * @param  chA–C         Timer channel for each motor phase.
 *
 * This function:
 *   - Computes the updated electrical angle based on RPM.
 *   - Calculates duty cycles for all three motor phases.
 *   - Updates PWM outputs for each phase using sine LUT.
 *
 * @note Call this function regularly (e.g., in your control loop or timer ISR).
 *
 * Example usage:
 *   control_motor(120.0f, 0.01f, &motor_axis, &htim1, TIM_CHANNEL_1, &htim1, TIM_CHANNEL_2, &htim15, TIM_CHANNEL_2);
 */
void control_motor(
    float speed_rpm,
    float dt,
    AxisControl_t *param,
    TIM_HandleTypeDef *htimA, uint32_t chA,
    TIM_HandleTypeDef *htimB, uint32_t chB,
    TIM_HandleTypeDef *htimC, uint32_t chC
) {
    MotorSpinOpenLoop(speed_rpm, dt, param, htimA, chA, htimB, chB, htimC, chC);
}

/**
 * @brief Run the main PID controller calculation.
 * @param error Error value to correct.
 * @param dt Time delta in seconds.
 * @param pid Pointer to PID_t structure.
 * @return PID output (float).
 */
float pid(float error, float dt, PID_t *pid){
	return PID_Update5(error,dt,pid);
}


void control_roll(void){
    float set_pitch = 0.0f;
    float set_yaw = 0.0f;

    param_roll.target_angle = rc_us_to_angle(usWidth[0], 45.0f);
    q_target_roll = euler_to_quat(EULER_CONVENTION_ZYX, param_roll.target_angle * DEG2RAD, set_pitch, set_yaw);

    quaternion q_error_roll = quat_mult(q_target_roll, quat_conj(q_est));

    float angle_vec_roll[3];
    quat_to_angle_vector(q_error_roll, angle_vec_roll);

    float roll_axis_world[3] = {1.0f, 0.0f, 0.0f};
    param_roll.angle_error = dot_product(angle_vec_roll, roll_axis_world);
    param_roll.target_velocity = pid(param_roll.angle_error, dt, &roll_outer);

    quaternion q_conjugate = quat_conj(q_est);
    float roll_axis_body[3];
    quat_rotate_vector(&q_conjugate, roll_axis_world, roll_axis_body);

    param_roll.rate = dot_product(gyro_body, roll_axis_body);
    param_roll.velocity_error = param_roll.target_velocity - param_roll.rate;
    param_roll.output = pid(param_roll.velocity_error, dt, &roll_inner);
    Low_pass_filter(param_roll.output, &param_roll.output_lp);

    param_roll.rpm = (60.0f / (2.0f * M_PI)) * param_roll.output_lp;
    control_motor(param_roll.rpm, dt, &roll_motor, &tim_roll_a, roll_a, &tim_roll_b, roll_b, &tim_roll_c, roll_c);
}


void control_pitch(void){
    float set_roll = 0.0f;
    float set_yaw  = 0.0f;

    param_pitch.target_angle = rc_us_to_angle(usWidth[1], 45.0f);
    q_target_pitch = euler_to_quat(EULER_CONVENTION_ZYX, set_roll, param_pitch.target_angle * DEG2RAD, set_yaw);

    quaternion q_error_pitch = quat_mult(q_target_pitch, quat_conj(q_est));

    float angle_vec_pitch[3];
    quat_to_angle_vector(q_error_pitch, angle_vec_pitch);

    float pitch_axis_world[3] = {0.0f, 1.0f, 0.0f};
    param_pitch.angle_error = dot_product(angle_vec_pitch, pitch_axis_world);
    param_pitch.target_velocity = pid(param_pitch.angle_error, dt, &pitch_outer);

    quaternion q_conjugate = quat_conj(q_est);
    float pitch_axis_body[3];
    quat_rotate_vector(&q_conjugate, pitch_axis_world, pitch_axis_body);

    param_pitch.rate = dot_product(gyro_body, pitch_axis_body);
    param_pitch.velocity_error = param_pitch.target_velocity - param_pitch.rate;
    param_pitch.output = pid(param_pitch.velocity_error, dt, &pitch_inner);
    Low_pass_filter(param_pitch.output, &param_pitch.output_lp);

    param_pitch.rpm = (60.0f / (2.0f * M_PI)) * param_pitch.output_lp;
    control_motor(param_pitch.rpm, dt, &pitch_motor, &tim_pitch_a, pitch_a, &tim_pitch_b, pitch_b, &tim_pitch_c, pitch_c);
}


void control_yaw(void) {

	//full_control

//    // 1. target quaternion เฉพาะ pitch เท่านั้น (roll, yaw = 0)
//    float set_roll = 0.0f;
//    float set_pitch  = 0.0f;
//    q_target_yaw = euler_to_quat(EULER_CONVENTION_ZYX, set_roll, set_pitch, setpoint_yaw * DEG2RAD);
//
//    // 2. หาความคลาดเคลื่อน quaternion ระหว่าง target กับปัจจุบัน
//    quaternion q_error_yaw = quat_mult(q_target_yaw, quat_conj(q_est));
//
//    // 3. คำนวณ angle vector ของ yaw
//    float angle_vec_yaw[3];
//    quat_to_angle_vector(q_error_yaw, angle_vec_yaw);
//
//    // 4. --- Outer loop ---
//    float yaw_axis_world[3] = {0.0f, 0.0f, 1.0f};
//    yaw_angle_error = dot_product(angle_vec_yaw, yaw_axis_world);
//    yaw_target_velocity = pid(yaw_angle_error, dt, &yaw_outer);
//
//    // 5. --- Inner loop with projection ---
//    quaternion q_conjugate = quat_conj(q_est);
//    float yaw_axis_body[3];
//    quat_rotate_vector(&q_conjugate, yaw_axis_world, yaw_axis_body);
//
//    yaw_rate = dot_product(gyro_body, yaw_axis_body);
//    yaw_velocity_error = yaw_target_velocity - yaw_rate;
//    yaw_output = pid(yaw_velocity_error, dt, &yaw_inner) ;
//    Low_pass_filter(yaw_output, &yaw_output_lp);
//
//    // 6. --- Convert to RPM & control motor ---
//    yaw_rpm = (60.0f / (2.0f * M_PI)) * yaw_output_lp;
//
//    control_motor(yaw_rpm , dt, &yaw_motor, &tim_yaw_a, yaw_a, &tim_yaw_b, yaw_b, &tim_yaw_c, yaw_c);


    //---non_control---
//	setpoint_yaw = rc_us_to_angle(rc_pulse_width[2], 180.0f);  //เป็นองศา
	float yaw_input_ui = yaw_outer.Kp;  // ค่าที่มาจาก UI


	if (yaw_input_ui == 0) {
		param_yaw.rpm = rc_us_to_angle(usWidth[2], 5.0f);
	} else {
		param_yaw.rpm = yaw_input_ui;
	}
	 control_motor(param_yaw.rpm , dt, &yaw_motor, &tim_yaw_a, yaw_a, &tim_yaw_b, yaw_b, &tim_yaw_c, yaw_c);

}


void copy_config_to_struct_eeprom(void) {

	eepromstruct.revision = FIRMWARE_VERSION;  // ⬅️ อัปเดตเวอร์ชันล่าสุด
    // 1. acc_calib
    memcpy(eepromstruct.accel_avg, accel_offset.avg, sizeof(eepromstruct.accel_avg));
    eepromstruct.accel_bias[0] = accel_offset.bias_x;
    eepromstruct.accel_bias[1] = accel_offset.bias_y;
    eepromstruct.accel_bias[2] = accel_offset.bias_z;

    eepromstruct.accel_scale[0] = accel_offset.scale_x;
    eepromstruct.accel_scale[1] = accel_offset.scale_y;
    eepromstruct.accel_scale[2] = accel_offset.scale_z;

    eepromstruct.accel_misalign[0] = accel_offset.mis_xy;
    eepromstruct.accel_misalign[1] = accel_offset.mis_xz;
    eepromstruct.accel_misalign[2] = accel_offset.mis_yx;
    eepromstruct.accel_misalign[3] = accel_offset.mis_yz;
    eepromstruct.accel_misalign[4] = accel_offset.mis_zx;
    eepromstruct.accel_misalign[5] = accel_offset.mis_zy;


    //2. gyro_calib
    eepromstruct.gyro_bias[0] = gyro_offset.bias_x;
    eepromstruct.gyro_bias[1] = gyro_offset.bias_y;
    eepromstruct.gyro_bias[2] = gyro_offset.bias_z;

    // 3. PID Roll
    eepromstruct.pid_roll[0] = roll_inner.Kp;
    eepromstruct.pid_roll[1] = roll_inner.Ki;
    eepromstruct.pid_roll[2] = roll_inner.Kd;
    eepromstruct.pid_roll[3] = roll_outer.Kp;
    eepromstruct.pid_roll[4] = roll_outer.Ki;
    eepromstruct.pid_roll[5] = roll_outer.Kd;

    // 4. PID Pitch
    eepromstruct.pid_pitch[0] = pitch_inner.Kp;
    eepromstruct.pid_pitch[1] = pitch_inner.Ki;
    eepromstruct.pid_pitch[2] = pitch_inner.Kd;
    eepromstruct.pid_pitch[3] = pitch_outer.Kp;
    eepromstruct.pid_pitch[4] = pitch_outer.Ki;
    eepromstruct.pid_pitch[5] = pitch_outer.Kd;

    // 5. PID Yaw
    eepromstruct.pid_yaw[0] = yaw_inner.Kp;
    eepromstruct.pid_yaw[1] = yaw_inner.Ki;
    eepromstruct.pid_yaw[2] = yaw_inner.Kd;
    eepromstruct.pid_yaw[3] = yaw_outer.Kp;
    eepromstruct.pid_yaw[4] = yaw_outer.Ki;
    eepromstruct.pid_yaw[5] = yaw_outer.Kd;

    // 6. Motor roll config
    eepromstruct.motor_roll[0] = roll_motor.percent_torque;
    eepromstruct.motor_roll[1] = roll_motor.POLE;

    eepromstruct.motor_pitch[0] = pitch_motor.percent_torque;
    eepromstruct.motor_pitch[1] = pitch_motor.POLE;

    eepromstruct.motor_yaw[0] = yaw_motor.percent_torque;
    eepromstruct.motor_yaw[1] = yaw_motor.POLE;



    // 7. Alpha
    eepromstruct.alpha[0] = gyro_alpha;
    eepromstruct.alpha[1] = alpha;

}

void load_struct_to_config_from_eeprom(void) {
    // 1. accel_Calibration
    memcpy(accel_offset.avg, eepromstruct.accel_avg, sizeof(accel_offset.avg));

    accel_offset.bias_x = eepromstruct.accel_bias[0];
    accel_offset.bias_y = eepromstruct.accel_bias[1];
    accel_offset.bias_z = eepromstruct.accel_bias[2];

    accel_offset.scale_x = eepromstruct.accel_scale[0];
    accel_offset.scale_y = eepromstruct.accel_scale[1];
    accel_offset.scale_z = eepromstruct.accel_scale[2];

    accel_offset.mis_xy = eepromstruct.accel_misalign[0];
    accel_offset.mis_xz = eepromstruct.accel_misalign[1];
    accel_offset.mis_yx = eepromstruct.accel_misalign[2];
    accel_offset.mis_yz = eepromstruct.accel_misalign[3];
    accel_offset.mis_zx = eepromstruct.accel_misalign[4];
    accel_offset.mis_zy = eepromstruct.accel_misalign[5];

    // 2. accel_Calibration
    gyro_offset.bias_x = eepromstruct.gyro_bias[0];
    gyro_offset.bias_y = eepromstruct.gyro_bias[1];
    gyro_offset.bias_z = eepromstruct.gyro_bias[2];

    // 3. PID Roll
    roll_inner.Kp = eepromstruct.pid_roll[0];
    roll_inner.Ki = eepromstruct.pid_roll[1];
    roll_inner.Kd = eepromstruct.pid_roll[2];
    roll_outer.Kp = eepromstruct.pid_roll[3];
    roll_outer.Ki = eepromstruct.pid_roll[4];
    roll_outer.Kd = eepromstruct.pid_roll[5];

    // 4. PID Pitch
    pitch_inner.Kp = eepromstruct.pid_pitch[0];
    pitch_inner.Ki = eepromstruct.pid_pitch[1];
    pitch_inner.Kd = eepromstruct.pid_pitch[2];
    pitch_outer.Kp = eepromstruct.pid_pitch[3];
    pitch_outer.Ki = eepromstruct.pid_pitch[4];
    pitch_outer.Kd = eepromstruct.pid_pitch[5];

    // 5. PID Yaw
    yaw_inner.Kp = eepromstruct.pid_yaw[0];
    yaw_inner.Ki = eepromstruct.pid_yaw[1];
    yaw_inner.Kd = eepromstruct.pid_yaw[2];
    yaw_outer.Kp = eepromstruct.pid_yaw[3];
    yaw_outer.Ki = eepromstruct.pid_yaw[4];
    yaw_outer.Kd = eepromstruct.pid_yaw[5];

    // 6. Motor config
    roll_motor.percent_torque  = eepromstruct.motor_roll[0];
    roll_motor.POLE            = eepromstruct.motor_roll[1];

    pitch_motor.percent_torque = eepromstruct.motor_pitch[0];
    pitch_motor.POLE           = eepromstruct.motor_pitch[1];

    yaw_motor.percent_torque   = eepromstruct.motor_yaw[0];
    yaw_motor.POLE             = eepromstruct.motor_yaw[1];



    // 7. Alpha filter
    gyro_alpha = eepromstruct.alpha[0];
    alpha      = eepromstruct.alpha[1];
}



/**
 * @brief Save EEPROM struct to flash memory.
 * @param page Flash memory page number.
 * @param offset Offset within page.
 */
void save_to_eeprom(uint16_t page, uint16_t offset)
{
    eepromstruct.revision += 1; // เพิ่ม revision ทุกครั้งที่ save
    //EEPROM_PageErase(0);
    EEPROM_Write(page, offset, (uint8_t*)&eepromstruct, sizeof(ConfigData_t));

    current_config_revision = eepromstruct.revision; // sync RAM
}


/**
 * @brief Load EEPROM data if a revision change is detected.
 * @param page Flash memory page.
 * @param offset Offset within page.
 */
void check_and_load_if_revision_changed(uint16_t page, uint16_t offset)
{
    uint32_t stored_revision = 0;

    // อ่าน revision เฉพาะ 4 bytes แรก
    EEPROM_Read(page, offset, (uint8_t*)&stored_revision, sizeof(uint32_t));

    // ✅ ตรวจว่าค่า valid ก่อนโหลด
    if (stored_revision != 0xFFFFFFFF && stored_revision != 0x00000000) {
        if (stored_revision != current_config_revision) {
            load_config_from_eeprom();
            current_config_revision = stored_revision;
        }
    }
}


void clear_pid_internal_state(void)
{
    roll_inner.integral = 0.0f;
    roll_inner.prev_error = 0.0f;

    pitch_inner.integral = 0.0f;
    pitch_inner.prev_error = 0.0f;

    yaw_inner.integral = 0.0f;
    yaw_inner.prev_error = 0.0f;

    roll_outer.integral = 0.0f;
    roll_outer.prev_error = 0.0f;

    pitch_outer.integral = 0.0f;
    pitch_outer.prev_error = 0.0f;

    yaw_outer.integral = 0.0f;
    yaw_outer.prev_error = 0.0f;
}

