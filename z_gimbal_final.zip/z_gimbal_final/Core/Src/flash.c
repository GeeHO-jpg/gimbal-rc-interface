/*
 * flash.c
 *
 *  Created on: Jun 23, 2025
 *      Author: _TTTXN
 */


/**
  ***************************************************************************************************************
  ***************************************************************************************************************
  ***************************************************************************************************************
  File:	      FLASH_PAGE_F1.c
  Modifier:   ControllersTech.com
  Updated:    27th MAY 2021
  ***************************************************************************************************************
  Copyright (C) 2017 ControllersTech.com
  This is a free software under the GNU license, you can redistribute it and/or modify it under the terms
  of the GNU General Public License version 3 as published by the Free Software Foundation.
  This software library is shared with public for educational purposes, without WARRANTY and Author is not liable for any damages caused directly
  or indirectly by this software, read more about this on the GNU General Public License.
  ***************************************************************************************************************
*/

#include "flash.h"


flash_t save_data;

/* STM32F103 have 128 PAGES (Page 0 to Page 127) of 1 KB each. This makes up 128 KB Flash Memory
 * Some STM32F103C8 have 64 KB FLASH Memory, so I guess they have Page 0 to Page 63 only.
 */





/* FLASH_PAGE_SIZE should be able to get the size of the Page according to the controller */
static uint32_t GetPageIndex(uint32_t Address)
{
  return (Address - FLASH_BASE_ADDRESS) / FLASH_PAGE_SIZE;
}


uint8_t bytes_temp[4];


void float2Bytes(uint8_t * ftoa_bytes_temp,float float_variable)
{
    union {
      float a;
      uint8_t bytes[4];
    } thing;

    thing.a = float_variable;

    for (uint8_t i = 0; i < 4; i++) {
      ftoa_bytes_temp[i] = thing.bytes[i];
    }

}

float Bytes2float(uint8_t * ftoa_bytes_temp)
{
    union {
      float a;
      uint8_t bytes[4];
    } thing;

    for (uint8_t i = 0; i < 4; i++) {
    	thing.bytes[i] = ftoa_bytes_temp[i];
    }

   float float_variable =  thing.a;
   return float_variable;
}

uint32_t Flash_Write_Data(uint32_t StartAddress, uint32_t *Data, uint16_t numberofwords)
{
    FLASH_EraseInitTypeDef EraseInitStruct;
    uint32_t PAGEError;
    int sofar = 0;
    __disable_irq();  // 🔒 ปิดการขัดจังหวะ
    HAL_FLASH_Unlock();

    uint32_t StartPage = GetPageIndex(StartAddress);
    uint32_t EndAddress = StartAddress + numberofwords * 4;
    uint32_t EndPage = GetPageIndex(EndAddress);

    // ป้องกันค่าขยะ
    memset(&EraseInitStruct, 0, sizeof(EraseInitStruct));
    EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
    EraseInitStruct.Page = StartPage;
    EraseInitStruct.NbPages = (EndPage - StartPage) + 1;
    EraseInitStruct.Banks = FLASH_BANK_1 ;  // ✅ ต้องใส่

    if (HAL_FLASHEx_Erase(&EraseInitStruct, &PAGEError) != HAL_OK)
    {
        HAL_FLASH_Lock();
        __enable_irq();  // ✅ เปิดกลับ
        return HAL_FLASH_GetError();
    }

    while (sofar < numberofwords)
    {
        uint64_t data64;

        if (sofar + 1 < numberofwords) {
            data64 = ((uint64_t)Data[sofar + 1] << 32) | Data[sofar];
        } else {
            data64 = ((uint64_t)0xFFFFFFFF << 32) | Data[sofar];
        }

        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, StartAddress, data64) == HAL_OK)
        {
            StartAddress += 8;
            sofar += 2;
        }
        else
        {
            HAL_FLASH_Lock();
            __enable_irq();  // ✅ เปิดกลับ
            return HAL_FLASH_GetError();
        }
    }

    HAL_FLASH_Lock();
    __enable_irq();  // ✅ เปิดกลับ


    return 0;
}


void Flash_Read_Data(uint32_t StartPageAddress, uint32_t *RxBuf, uint16_t numberofwords)
{
    while (numberofwords--)
    {
        *RxBuf++ = *(__IO uint32_t *)StartPageAddress;
        StartPageAddress += 4;
    }
}
void Convert_To_Str (uint32_t *Data, char *Buf)
{
	int numberofbytes = ((strlen((char *)Data)/4) + ((strlen((char *)Data) % 4) != 0)) *4;

	for (int i=0; i<numberofbytes; i++)
	{
		Buf[i] = Data[i/4]>>(8*(i%4));
	}
}


void Flash_Write_NUM (uint32_t StartSectorAddress, float Num)
{

	float2Bytes(bytes_temp, Num);

	Flash_Write_Data (StartSectorAddress, (uint32_t *)bytes_temp, 1);
}


float Flash_Read_NUM (uint32_t StartSectorAddress)
{
	uint8_t buffer[4];
	float value;

	Flash_Read_Data(StartSectorAddress, (uint32_t *)buffer, 1);
	value = Bytes2float(buffer);
	return value;
}

void Flash_Erase_Page(uint32_t address)
{
    HAL_FLASH_Unlock();

    FLASH_EraseInitTypeDef erase;
    uint32_t page_error;

    erase.TypeErase = FLASH_TYPEERASE_PAGES;
    erase.Page = (address - FLASH_BASE) / FLASH_PAGE_SIZE;  // FLASH_BASE = 0x08000000
    erase.NbPages = 1;

    HAL_FLASHEx_Erase(&erase, &page_error);

    HAL_FLASH_Lock();
}


