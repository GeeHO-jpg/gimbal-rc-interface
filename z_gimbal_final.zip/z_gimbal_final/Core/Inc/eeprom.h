/*
 * eeprom.h
 *
 *  Created on: Jun 25, 2025
 *      Author: _TTTXN
 */

#ifndef INC_EEPROM_H_
#define INC_EEPROM_H_

#include "main.h"
#include "math.h"
#include "string.h"
#include "i2c.h"
#include "cmsis_os2.h"

extern osSemaphoreId_t eeprom_sem;  // ✅ global handle สำหรับใช้ใน EEPROM


#define EEPROM_TIMEOUT 1000
#define MAX_PENDING_WRITE_SIZE 128

//define the I2C
#define EEPROM_I2C &hi2c2

// EEPROM ADDRESS (8bits)
#define EEPROM_ADDR 0xA0

// Define the Page Size and number of pages
#define PAGE_SIZE 64     // page in Bytes
#define PAGE_NUM  512    // number of pages

#define CONFIG_PAGE     0
#define CONFIG_OFFSET   0
#define VALID_REVISION  1

#define FIRMWARE_VERSION 2001

typedef struct{
	uint32_t revision;
    float accel_avg[6][3]; // ค่าความเร่งจากทิศ X+,X−,Y+,Y−,Z+,Z−
    float accel_bias[3];
    float accel_scale[3];
    float accel_misalign[6];
    float gyro_bias[3];    // bias แกน X, Y, Z
    float pid_roll[6];    // PID inner and PID outer
    float pid_pitch[6];    // PID inner and PID outer
    float pid_yaw[6];    	// PID inner and PID outer
    float motor_roll[2]; // percnt_torque,pole
    float motor_pitch[2]; // percnt_torque,pole
    float motor_yaw[2]; // percnt_torque,pole
    float alpha[2];			//gyro_alpha,output_alpha
}ConfigData_t;



extern ConfigData_t eepromstruct,eeprom_recieve;
extern uint32_t current_config_revision;
extern uint8_t flag;

extern volatile uint8_t eeprom_write_done;



void EEPROM_Write (uint16_t page, uint16_t offset, uint8_t *data, uint16_t size);
void EEPROM_Read (uint16_t page, uint16_t offset, uint8_t *data, uint16_t size);
void EEPROM_PageErase (uint16_t page);
HAL_StatusTypeDef EEPROM_Write_IT(uint16_t page, uint16_t offset, uint8_t *data, uint16_t size);
HAL_StatusTypeDef EEPROM_Write_IT_RTOS(uint16_t page, uint16_t offset, uint8_t *data, uint16_t size);
HAL_StatusTypeDef EEPROM_Read_RTOS(uint16_t page, uint16_t offset, uint8_t *data, uint16_t size);
HAL_StatusTypeDef EEPROM_Write_Blocking(uint16_t page, uint16_t offset, uint8_t *data, uint16_t size);

void reset_to_default_config(void);
void save_config_to_eeprom(void);
void load_config_from_eeprom(void);



void EEPROM_Write_NUM (uint16_t page, uint16_t offset, float  fdata);
float EEPROM_Read_NUM (uint16_t page, uint16_t offset);

#endif /* INC_EEPROM_H_ */
