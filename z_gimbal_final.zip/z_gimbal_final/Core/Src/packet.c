/*
 * packet.c
 *
 *  Created on: Apr 22, 2025
 *      Author: _TTTXN
 */

#include "app.h"
#include "packet.h"

Packet pk = {0};
uint8_t crc_input[MAX_PACKET_SIZE] = {0};
uint8_t temp[32] = {0};
bool reinit_requested = 0;
volatile uint8_t write_eeprom_requested = 0;

bool decode_packet(uint8_t *packet, uint16_t length) {

	//clear values
	memset(pk.values, 0, sizeof(pk.values));


    if (length < 8) {
        pk.valid = false;
        return false;
    }

    if (packet[0] != HEADER_BYTE) {
        pk.valid = false;
        return false;
    }

    pk.payload_size = packet[1];
    pk.cmd = packet[2];
    pk.flags = packet[3];

    // --- เตรียม buffer สำหรับ CRC (byte-wise) ---
//    uint8_t crc_input[64] = {0};   // เพียงพอสำหรับ cmd + flags + floats
    memcpy(&crc_input[0], &packet[2], pk.payload_size - 4);  // copy เฉพาะ cmd+flags+float

    pk.crc_calculated = calculate_crc_bytes(crc_input, pk.payload_size - 4);

    // ดึง CRC ที่ฝังมาในแพ็กเกจ (4 byte สุดท้ายของ payload)
    memcpy(&pk.crc_received, &packet[2 + pk.payload_size - 4], 4);

    if (pk.crc_calculated != pk.crc_received) {
        pk.valid = false;
        return false;
    }

    pk.num_floats = (pk.payload_size - 2 - 4) / 4;  // 2 = cmd+flags, 4 = CRC

    if (pk.num_floats > MAX_FLOATS) {
        pk.valid = false;
        return false;
    }
    for (int i = 0; i < pk.num_floats && i < MAX_FLOATS; ++i) {
        memcpy(&pk.values[i], &packet[4 + i * 4], sizeof(float));
    }

//    for (int i = 0; i < pk.num_floats; ++i) {
//        memcpy(&pk.values[i], &packet[4 + i * 4], sizeof(float));
//    }

    pk.valid = true;
    return true;
}

void handle_command(uint8_t cmd, float* values, int num_values) {
    switch (cmd) {


    		break;
        case 0x01:  // Start Accelerometer Calibration Step
            if (pk.flags & 0x01) {
                startCalibration = 1;  // set flag ให้ loop ทำงาน
            }
            break;

        case 0x02:  // Start Gyroscope Calibration
            if (pk.flags & 0x01) {

            	startGyroCalib = 1;  // set flag ให้ loop ทำงาน
            }
            break;
        case 0x03:  // reset Calibration
            if (pk.flags & 0x01) {

            	reset_cal();  // set flag ให้ loop ทำงาน

            	reinit_requested = 1;
            }
            break;
        case 0x04:  // pid & alpha
            if (pk.flags & 0x01) {
            	roll_inner.Kp = values[0];
            	roll_inner.Ki = values[3];
            	roll_inner.Kd = values[6];
            	roll_outer.Kp = values[9];

            	pitch_inner.Kp = values[1];
            	pitch_inner.Ki = values[4];
            	pitch_inner.Kd = values[7];
            	pitch_outer.Kp = values[10];

            	gyro_alpha = values[12];
            	alpha = values[13];



              // เอาไว้บันทึกค่าในramลง eeprom
            }
            break;
        case 0x05:  // align yaw
            if (pk.flags & 0x01) {

            	yaw_outer.Kd = 1;
            	yaw_outer.Kp = values[0];

            }
            break;
        case 0x06:  // pole
            if (pk.flags & 0x01) {
            	roll_motor.POLE = values[0];
            	pitch_motor.POLE = values[1];
            	yaw_motor.POLE = values[2];

            }
            break;
        case 0x07:  // percent torque
            if (pk.flags & 0x01) {
            	roll_motor.percent_torque = values[0];
            	pitch_motor.percent_torque = values[1];
            	yaw_motor.percent_torque = values[2];

            }
            break;
        case 0x10:  // เอาไว้บันทึกค่าในramลง eeprom
            if (pk.flags & 0x01) {
            	write_eeprom_requested = 1;
            }
            if (pk.flags & 0x00) {
                       	write_eeprom_requested = 0;
                       }
            break;
    	case 0x99:  // reset data in pk struct

    			memset(pk.values,0,sizeof(pk.values));


        default:
            break;
    }
}

uint32_t calculate_crc_bytes(uint8_t* data, uint32_t length) {
    __HAL_CRC_DR_RESET(&hcrc);
    for (uint32_t i = 0; i < length; i++) {
        *((__IO uint8_t*)&hcrc.Instance->DR) = data[i];
    }
    return hcrc.Instance->DR;
}




 /*
  * bool decode_packet(uint8_t *packet, uint16_t length){

	//เช็ค len เริ่มต้น
    if (length < 6) return false;

    //check header
    if (packet[0] != 0xAA) return false;  // ตรวจ header

    //check payload size
    payload_size = packet[1];
    payload_size_float = (float)packet[1];


    if (length !=  (payload_size + 2) ) return false;

    // คำนวณ CRC
    crc_cal = HAL_CRC_Calculate(&hcrc, (uint32_t*)&packet[2], (payload_size - 4));
    crc_cal_simple = HAL_CRC_Calculate(&hcrc, (uint32_t*)simple, sizeof(simple));

    //CRC received
    memcpy(&crc_recv, &packet[payload_size - 2], 4);

    //check crc
    if (crc_cal != crc_recv) return false;

    //convert bytes -> float
    int num_floats = (payload_size - 4)/4;
    for (int i = 0; i < num_floats; i++) {
        memcpy(&values[i], &packet[2 + i * 4], sizeof(float));
    }

    return true;
}
static int8_t CDC_Receive_FS(uint8_t* Buf, uint32_t *Len)
{
   USER CODE BEGIN 6
  USBD_CDC_SetRxBuffer(&hUsbDeviceFS, &Buf[0]);
  USBD_CDC_ReceivePacket(&hUsbDeviceFS);

  len = (uint8_t)*Len;
  memset(buffer,'\0',sizeof(buffer));
  memcpy(buffer,Buf,len);
  memset(Buf,'\0',len);

  bool result = decode_packet(buffer, len);
  if (result) {
//      printf("✅ Packet ถูกต้อง!\n");
//      printf("Header: 0x%02X\n", pk.header);
//      printf("Cmd: 0x%02X\n", pk.cmd);
//      for (int i = 0; i < pk.payload_len; ++i) {
//          printf("Payload[%d] = %f\n", i, pk.payload[i]);
//      }
  } else {
//      printf(" wrong Packet CRC  Format\n");
//      for (int i = 0; i < pk.payload_len; ++i) {
//          printf("Payload[%d] = %f\n", i, pk.payload[i]);
//      }
  }

*/

