/*
 * filter.c
 *
 *  Created on: Jun 2, 2025
 *      Author: _TTTXN
 */

#include "filter.h"

float BETA = 0.4f;

float gyro_alpha = 0.1f;
float alpha = 0.1f;
float drift_gain;
float yaw_bias;






  quaternion q_w,q_w_s,q_w_g,q_est_prev;
  quaternion q_est = { 1, 0, 0, 0};       // initialize with as unit vector with real component  = 1
  quaternion q_target = {1.0f, 0.0f, 0.0f, 0.0f}; // ตัวอย่าง: target orientation เป็นแนวตรง
  quaternion q_error;


quaternion quat_mult ( quaternion L,  quaternion R){


     quaternion product;
    product.q1 = (L.q1 * R.q1) - (L.q2 * R.q2) - (L.q3 * R.q3) - (L.q4 * R.q4);
    product.q2 = (L.q1 * R.q2) + (L.q2 * R.q1) + (L.q3 * R.q4) - (L.q4 * R.q3);
    product.q3 = (L.q1 * R.q3) - (L.q2 * R.q4) + (L.q3 * R.q1) + (L.q4 * R.q2);
    product.q4 = (L.q1 * R.q4) + (L.q2 * R.q3) - (L.q3 * R.q2) + (L.q4 * R.q1);

    return product;
}


// The resulting quaternion is a global variable (q_est), so it is not returned or passed by reference/pointer
// Gyroscope Angular Velocity components are in Radians per Second
// Accelerometer componets will be normalized
void imu_filter(float ax, float ay, float az, float gx, float gy, float gz){

    //Variables and constants
	 q_est_prev = q_est;
     quaternion q_est_dot = {0};            // used as a place holder in equations 42 and 43
    //const struct quaternion q_g_ref = {0, 0, 0, 1};// equation (23), reference to field of gravity for gradient descent optimization (not needed because I used eq 25 instead of eq 21
     quaternion q_a = {0, ax, ay, az};    // equation (24) raw acceleration values, needs to be normalized

    float F_g [3] = {0};                        // equation(15/21/25) objective function for gravity
    float J_g [3][4] = {0};                     // jacobian matrix for gravity

     quaternion gradient = {0};

    /* Integrate angluar velocity to obtain position in angles. */
//     quaternion q_w;                   // equation (10), places gyroscope readings in a quaternion
    q_w.q1 = 0;                              // the real component is zero, which the Madgwick uses to simplfy quat. mult.
    q_w.q2 = gx;
    q_w.q3 = gy;
    q_w.q4 = gz;

     q_w_s = q_w;
    quat_scalar(&q_w_s, 0.5);                  // equation (12) dq/dt = (1/2)q*w
     q_w_g = quat_mult(q_est_prev, q_w_s);        // equation (12)

     q_w = q_w_g;
    /* NOTE
    * Page 10 states equation (40) substitutes equation (13) into it. This seems false, as he actually
    * substitutes equation (12), q_se_dot_w, not equation (13), q_se_w.
    *
    * // quat_scalar(&q_w, deltaT);               // equation (13) integrates the angles velocity to position
    * // quat_add(&q_w, q_w, q_est_prev);         // addition part of equation (13)
    */

    /* Compute the gradient by multiplying the jacobian matrix by the objective function. This is equation 20.
     The Jacobian matrix, J, is a 3x4 matrix of partial derivatives for each quaternion component in the x y z axes
     The objective function, F, is a 3x1 matrix for x y and z.
     To multiply these together, the inner dimensions must match, so use J'.
     I calculated "by hand" the transpose of J, so I will be using "hard coordinates" to get those values from J.
     The matrix multiplcation can also be done hard coded to reduce code.

     Note: it is possible to compute the objective function with quaternion multiplcation functions, but it does not take into account the many zeros that cancel terms out and is not optimized like the paper shows
     */

    quat_Normalization(&q_a);              // normalize the acceleration quaternion to be a unit quaternion
    //Compute the objective function for gravity, equation(15), simplified to equation (25) due to the 0's in the acceleration reference quaternion
    F_g[0] = 2*(q_est_prev.q2 * q_est_prev.q4 - q_est_prev.q1 * q_est_prev.q3) - q_a.q2;
    F_g[1] = 2*(q_est_prev.q1 * q_est_prev.q2 + q_est_prev.q3* q_est_prev.q4) - q_a.q3;
    F_g[2] = 2*(0.5 - q_est_prev.q2 * q_est_prev.q2 - q_est_prev.q3 * q_est_prev.q3) - q_a.q4;

    //Compute the Jacobian matrix, equation (26), for gravity
    J_g[0][0] = -2 * q_est_prev.q3;
    J_g[0][1] =  2 * q_est_prev.q4;
    J_g[0][2] = -2 * q_est_prev.q1;
    J_g[0][3] =  2 * q_est_prev.q2;

    J_g[1][0] = 2 * q_est_prev.q2;
    J_g[1][1] = 2 * q_est_prev.q1;
    J_g[1][2] = 2 * q_est_prev.q4;
    J_g[1][3] = 2 * q_est_prev.q3;

    J_g[2][0] = 0;
    J_g[2][1] = -4 * q_est_prev.q2;
    J_g[2][2] = -4 * q_est_prev.q3;
    J_g[2][3] = 0;

    // now computer the gradient, equation (20), gradient = J_g'*F_g
    gradient.q1 = J_g[0][0] * F_g[0] + J_g[1][0] * F_g[1] + J_g[2][0] * F_g[2];
    gradient.q2 = J_g[0][1] * F_g[0] + J_g[1][1] * F_g[1] + J_g[2][1] * F_g[2];
    gradient.q3 = J_g[0][2] * F_g[0] + J_g[1][2] * F_g[1] + J_g[2][2] * F_g[2];
    gradient.q4 = J_g[0][3] * F_g[0] + J_g[1][3] * F_g[1] + J_g[2][3] * F_g[2];

    // Normalize the gradient, equation (44)
    quat_Normalization(&gradient);

    /* This is the sensor fusion part of the algorithm.
     Combining Gyroscope position angles calculated in the beginning, with the quaternion orienting the accelerometer to gravity created above.
     Noticably this new quaternion has not be created yet, I have only calculated the gradient in equation (19).
     Madgwick however uses assumptions with the step size and filter gains to optimize the gradient descent,
        combining it with the sensor fusion in equations (42-44).
     He says the step size has a var alpha, which he assumes to be very large.
     This dominates the previous estimation in equation (19) to the point you can ignore it.
     Eq. 36 has the filter gain Gamma, which is related to the step size and thus alpha. With alpha being very large,
        you can make assumptions to simplify the fusion equatoin of eq.36.
     Combining the simplification of the gradient descent equation with the simplification of the fusion equation gets you eq.
     41 which can be subdivided into eqs 42-44.
    */
    quat_scalar(&gradient, BETA);             // multiply normalized gradient by beta
    quat_sub(&q_est_dot, q_w, gradient);        // subtract above from q_w, the integrated gyro quaternion
    quat_scalar(&q_est_dot, DELTA_T);
    quat_add(&q_est, q_est_prev, q_est_dot);     // Integrate orientation rate to find position
    quat_Normalization(&q_est);                 // normalize the orientation of the estimate
                                                //(shown in diagram, plus always use unit quaternions for orientation)

}

quaternion quat_conj(quaternion q) {
    quaternion r = {q.q1, -q.q2, -q.q3, -q.q4};
    return r;
}

quaternion quat_error(quaternion q_target, quaternion q_measured) {
    quaternion q_inv = quat_conj(q_measured);
    return quat_mult(q_target, q_inv);
}

void quat_to_angle_vector(quaternion q_err, float *e_vec) {
    // ใช้ vector part เท่านั้น (สำหรับ error เล็กๆ)
    e_vec[0] = 2.0f * q_err.q2; // Roll error (X)
    e_vec[1] = 2.0f * q_err.q3; // Pitch error (Y)
    e_vec[2] = 2.0f * q_err.q4; // Yaw error (Z)
}

quaternion euler_to_quat(EulerConvention mode,float roll, float pitch, float yaw) {
    quaternion q;
    switch (mode) {
    case EULER_CONVENTION_ZYX: {
        float cy = cosf(yaw * 0.5f);
        float sy = sinf(yaw * 0.5f);
        float cp = cosf(pitch * 0.5f);
        float sp = sinf(pitch * 0.5f);
        float cr = cosf(roll * 0.5f);
        float sr = sinf(roll * 0.5f);

        q.q1 = cr * cp * cy + sr * sp * sy;
        q.q2 = sr * cp * cy - cr * sp * sy;
        q.q3 = cr * sp * cy + sr * cp * sy;
        q.q4 = cr * cp * sy - sr * sp * cy;
        break;
    }
    case EULER_CONVENTION_XYZ: {
        float cr = cosf(roll * 0.5f);
        float sr = sinf(roll * 0.5f);
        float cp = cosf(pitch * 0.5f);
        float sp = sinf(pitch * 0.5f);
        float cy = cosf(yaw * 0.5f);
        float sy = sinf(yaw * 0.5f);

        q.q1 = cr * cp * cy - sr * sp * sy;
        q.q2 = sr * cp * cy + cr * sp * sy;
        q.q3 = cr * sp * cy - sr * cp * sy;
        q.q4 = cr * cp * sy + sr * sp * cy;
        break;
    }
    }
    return q;
}



void filter_init(void){
    if (isnan(q_est.q1) || isnan(q_est.q2) || isnan(q_est.q3) || isnan(q_est.q4)) {
        q_est.q1 = 1.0f;
        q_est.q2 = 0.0f;
        q_est.q3 = 0.0f;
        q_est.q4 = 0.0f;
    }
}

void eulerFromQuanternion(EulerConvention mode, quaternion q, float *roll, float *pitch, float *yaw){

	float q1 = q.q1, q2 = q.q2, q3 = q.q3, q4 = q.q4;

    float q1q1 = q1*q1, q2q2 = q2*q2, q3q3 = q3*q3, q4q4 = q4*q4;
    float q1q2 = q1*q2, q1q3 = q1*q3, q1q4 = q1*q4;
    float q2q3 = q2*q3, q2q4 = q2*q4;
    float q3q4 = q3*q4;


	switch(mode){
	case EULER_CONVENTION_XYZ:
        *yaw = -atan2f((2*q2q3 - 2*q1q4), (2.0f * q1q1 + 2.0f * q2q2 - 1.0f));
        *pitch = asinf(2.0f * (q2q4 + q1q3));
        *roll  = -atan2f((2.0f * q3q4 - 2.0f * q1q2), (2.0f * q1q1 + 2.0f * q4q4 - 1.0f));
        break;

    case EULER_CONVENTION_ZYX:
        // 1) yaw (ψ) = หมุนรอบแกน Z
        //      ψ = atan2( 2 (q2⋅q3 + q1⋅q4),  q1² + q2² − q3² − q4² )
        *yaw = atan2f(2.0f * (q2q3 + q1q4), q1q1 + q2q2 - q3q3 - q4q4);

        // 2) pitch (θ) = หมุนรอบแกน Y
        //      θ = asin( 2 (q1⋅q3 − q4⋅q2) )
        *pitch = asinf(2.0f * (q1q3 - q2q4));

        // 3) roll (ϕ) = หมุนรอบแกน X
        //      ϕ = atan2( 2 (q3⋅q4 + q1⋅q2),  q1² − q2² − q3² + q4² )
        *roll = atan2f(2.0f * (q3q4 + q1q2), q1q1 - q2q2 - q3q3 + q4q4);

        break;
	}

    *yaw *= RAD_2_DEG;
    *pitch *= RAD_2_DEG;
    *roll *= RAD_2_DEG;

}

void quat_rotate_vector(const quaternion *q, const float v_in[3], float v_out[3]) {
    float x = q->q2, y = q->q3, z = q->q4, w = q->q1;

    float t2 =   w * x;
    float t3 =   w * y;
    float t4 =   w * z;
    float t5 =  -x * x;
    float t6 =   x * y;
    float t7 =   x * z;
    float t8 =  -y * y;
    float t9 =   y * z;
    float t10 = -z * z;

    v_out[0] = 2.0f*((t8 + t10)*v_in[0] + (t6 -  t4)*v_in[1] + (t3 + t7)*v_in[2]) + v_in[0];
    v_out[1] = 2.0f*((t4 +  t6)*v_in[0] + (t5 + t10)*v_in[1] + (t9 - t2)*v_in[2]) + v_in[1];
    v_out[2] = 2.0f*((t7 -  t3)*v_in[0] + (t2 + t9)*v_in[1] + (t5 + t8)*v_in[2]) + v_in[2];
}


void LP_filter(float w_x, float w_y, float w_z, float *gx_lp, float *gy_lp, float *gz_lp) {
    *gx_lp = gyro_alpha * (*gx_lp) + (1.0f - gyro_alpha) * w_x;
    *gy_lp = gyro_alpha * (*gy_lp) + (1.0f - gyro_alpha) * w_y;
    *gz_lp = gyro_alpha * (*gz_lp) + (1.0f - gyro_alpha) * w_z;
}


void Low_pass_filter(float in,float *out){
	*out = alpha * (*out) + (1.0f - alpha) * in;
}


// คำนวณ cross product: c = a × b
static void cross_product(float a[3], float b[3], float c[3]) {
    c[0] = a[1]*b[2] - a[2]*b[1];
    c[1] = a[2]*b[0] - a[0]*b[2];
    c[2] = a[0]*b[1] - a[1]*b[0];
}

/**
 * @brief ชดเชยค่าเร่งที่เกิดจากการวาง IMU ห่างจากจุดหมุน (lever arm)
 *
 * @param accel_meas       ค่าเร่งที่วัดได้จาก IMU (ใน world frame หรือ body frame)
 * @param gyro_body        ความเร็วเชิงมุมของ IMU (ใน body frame) [rad/s]
 * @param dt               เวลา dt [s] ใช้ในอนาคตถ้ามี tangential accel
 * @param lever_arm_body   เวกเตอร์ lever arm (ตำแหน่ง IMU จากจุดหมุนใน body frame) [m]
 * @param accel_corrected  เอาต์พุตค่าเร่งหลังหัก offset [same frame as accel_meas]
 */
void compensate_lever_arm(
    const float accel_meas[3],
    const float gyro_body[3],
    float dt,
    const float lever_arm_body[3],
    float accel_corrected[3]
) {
    // 1) omega × r
    float wxr[3] = {
        gyro_body[1]*lever_arm_body[2] - gyro_body[2]*lever_arm_body[1],
        gyro_body[2]*lever_arm_body[0] - gyro_body[0]*lever_arm_body[2],
        gyro_body[0]*lever_arm_body[1] - gyro_body[1]*lever_arm_body[0]
    };

    // 2) omega × (omega × r) → centrifugal acceleration
    float a_centripetal[3] = {
        gyro_body[1]*wxr[2] - gyro_body[2]*wxr[1],
        gyro_body[2]*wxr[0] - gyro_body[0]*wxr[2],
        gyro_body[0]*wxr[1] - gyro_body[1]*wxr[0]
    };

    // 3) หักค่าเร่งส่วนนี้ออกจาก accel_meas
    for (int i = 0; i < 3; i++) {
        accel_corrected[i] = accel_meas[i] - a_centripetal[i];
    }
}

void update_yaw_bias(float yaw_rate) {
    if (fabs(yaw_rate) < 0.5f) {  // system นิ่ง → drift
        yaw_bias += drift_gain * yaw_rate;
    }
}


