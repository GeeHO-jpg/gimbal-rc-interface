/*
 * rc_input.c
 *
 *  Created on: Jun 29, 2025
 *      Author: _TTTXN
 */
#include "rc_input.h"

volatile uint32_t rc_rise_time[3] = {0};       // สำหรับ TIM_CHANNEL_2/3/4
volatile uint32_t rc_pulse_width[3] = {1500, 1500, 1500};  // ค่า default ~ 1500 us (center)
volatile bool rc_capturing[3] = {false};

void input_init(void){
    HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_2);  // ใช้กับ RC ch2 roll
    HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_3);  // ใช้กับ RC ch3 pitch
    HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_4);  // ใช้กับ RC ch4 yaw
}

float rc_us_to_normalized(uint32_t pulse_us) {
    // แปลง 1000–2000us → -1.0 ถึง +1.0
    float value = ((int)pulse_us - 1500) / 500.0f;
    if (value > 1.0f) value = 1.0f;
    if (value < -1.0f) value = -1.0f;
    return value;
}


float rc_us_to_angle(uint32_t pulse_us, float max_angle_deg) {
    return rc_us_to_normalized(pulse_us) * max_angle_deg;
}


