/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32g0xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32g0xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "rc_input.h"
#include "eeprom.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define CLK 64000000

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

uint32_t usWidth[3]={1500,1500,1500};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern PCD_HandleTypeDef hpcd_USB_DRD_FS;
extern I2C_HandleTypeDef hi2c2;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim6;

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M0+ Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/******************************************************************************/
/* STM32G0xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32g0xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles USB, UCPD1 and UCPD2 global interrupts.
  */
void USB_UCPD1_2_IRQHandler(void)
{
  /* USER CODE BEGIN USB_UCPD1_2_IRQn 0 */

  /* USER CODE END USB_UCPD1_2_IRQn 0 */
  HAL_PCD_IRQHandler(&hpcd_USB_DRD_FS);
  /* USER CODE BEGIN USB_UCPD1_2_IRQn 1 */

  /* USER CODE END USB_UCPD1_2_IRQn 1 */
}

/**
  * @brief This function handles TIM2 global interrupt.
  */
void TIM2_IRQHandler(void)
{
  /* USER CODE BEGIN TIM2_IRQn 0 */

  /* USER CODE END TIM2_IRQn 0 */
  HAL_TIM_IRQHandler(&htim2);
  /* USER CODE BEGIN TIM2_IRQn 1 */

  /* USER CODE END TIM2_IRQn 1 */
}

/**
  * @brief This function handles TIM6, DAC and LPTIM1 global Interrupts.
  */
void TIM6_DAC_LPTIM1_IRQHandler(void)
{
  /* USER CODE BEGIN TIM6_DAC_LPTIM1_IRQn 0 */

  /* USER CODE END TIM6_DAC_LPTIM1_IRQn 0 */
  HAL_TIM_IRQHandler(&htim6);
  /* USER CODE BEGIN TIM6_DAC_LPTIM1_IRQn 1 */

  /* USER CODE END TIM6_DAC_LPTIM1_IRQn 1 */
}

/**
  * @brief This function handles I2C2, I2C3 Interrupt (combined with EXTI 24 and EXTI 22).
  */
void I2C2_3_IRQHandler(void)
{
  /* USER CODE BEGIN I2C2_3_IRQn 0 */

  /* USER CODE END I2C2_3_IRQn 0 */
  if (hi2c2.Instance->ISR & (I2C_FLAG_BERR | I2C_FLAG_ARLO | I2C_FLAG_OVR))
  {
    HAL_I2C_ER_IRQHandler(&hi2c2);
  }
  else
  {
    HAL_I2C_EV_IRQHandler(&hi2c2);
  }
  /* USER CODE BEGIN I2C2_3_IRQn 1 */

  /* USER CODE END I2C2_3_IRQn 1 */
}

/* USER CODE BEGIN 1 */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    static uint32_t IC_Val1[3] = {0};
    static uint32_t IC_Val2[3] = {0};
    static bool Is_First_capture[3] = {0};

    uint8_t ch = 0;
    uint32_t ic_val = 0;
    uint32_t diff = 0;

    // เลือก channel index
    if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2) { //roll
        ch = 0;
        ic_val = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
    } else if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_3) {//pitch
        ch = 1;
        ic_val = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_3);
    } else if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_4) { //yaw
        ch = 2;
        ic_val = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_4);
    } else {
        return; // Not a valid channel
    }

    // เริ่มวัดรอบแรก
    if(!Is_First_capture[ch])
    {
        IC_Val1[ch] = ic_val;
        Is_First_capture[ch] = true;
    }
    else
    {
        IC_Val2[ch] = ic_val;

        if(IC_Val2[ch] > IC_Val1[ch])
            diff = IC_Val2[ch] - IC_Val1[ch];
        else
            diff = (htim->Init.Period - IC_Val1[ch]) + IC_Val2[ch] + 1;

        float refClock = CLK / (float)htim->Init.Prescaler;  // ต้องใช้ float
        float tick_us = 1e6f / refClock;

        usWidth[ch] = diff * tick_us;  // แยกตาม ch → usWidth[0/1/2]

        Is_First_capture[ch] = false;
    }
}

//void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
//{
//	if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2)
//	{
//		if(Is_First_capture == 0)
//		{
//			IC_Val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
//			Is_First_capture =1;
//		}
//		else
//		{
//			IC_Val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
//			if(IC_Val2 > IC_Val1)
//			{
//				Difference = IC_Val2 - IC_Val1;
//			}
//			else if(IC_Val1 > IC_Val2)
//			{
//				Difference = (htim2.Init.Period  - IC_Val1)+IC_Val2;
//			}
//			float refClock =CLK/htim2.Init.Prescaler;
//			float mFactor = 1000000/refClock;
//
//
//
//			usWidth[0] = Difference*mFactor;
//
//
//			__HAL_TIM_SET_COUNTER(htim,0);
//			Is_First_capture=0;
//		}
//	}
//}

//void HAL_I2C_MemTxCpltCallback(I2C_HandleTypeDef *hi2c) {
//    if (hi2c == &hi2c2) {
//        eeprom_write_done = 1;
//        if (eeprom_sem != NULL) {
//            osSemaphoreRelease(eeprom_sem);
//        }
//    }
//}

/* USER CODE END 1 */
