/*
 * sensor.h
 *
 *  Created on: Jun 1, 2025
 *      Author: _TTTXN
 */

#ifndef INC_SENSOR_H_
#define INC_SENSOR_H_

#include "main.h"
#include "i2c.h"
#include <math.h>
#include <string.h>



#define FIFO_MAX_PKG 1
#define CALIB_SAMPLES 1000

typedef enum {
	STATE_IDLE,
	STATE_READ_COUNT,
	STATE_READ_DATA
} FIFO_State ;

typedef enum
{
	ub_0,
	ub_1,
	ub_2,
	ub_3,
	ub_4
}userbank;

typedef struct {
    uint8_t header;
    int16_t accel[3];
    int16_t gyro[3];
    int8_t temperature;
    uint16_t timestamp;
} FIFOData;

typedef struct {
    float roll;
    float pitch;
    float yaw;
} rpy_t;

typedef enum
{
	_2000dps,
	_1000dps,
	_500dps,
	_250dps,
	_125dps,
	_65_5dps,
	_31_25dps,
	_15_625dps


} gyro_full_scale;

typedef enum
{
	_32g,
	_16g,
	_8g,
	_4g,


}accel_full_scale;

typedef struct
{
	float x;
	float y;
	float z;

} axises;


typedef struct {
	float Q_angle;
    float Q_bias;
    float R_measure;
    float angle;
    float bias;
    float P[2][2];
} Kalman_t;


typedef struct {
    float avg[6][3];      // เก็บค่าเฉลี่ย [position][axis] (0→X+,1→X−,2→Y+,3→Y−,4→Z+,5→Z−)
    float bias_x, bias_y, bias_z;
    float scale_x, scale_y, scale_z;
    float mis_xy,mis_xz,mis_yx,mis_yz,mis_zx,mis_zy;
    float xtoy,xtoz,ytox,ytoz,ztox,ztoy;
    uint8_t lastPosition; // เก็บตำแหน่งล่าสุดที่ calib ไปแล้ว
}Calib_t;


extern float gyro_scale_factor, accel_scale_factor;
extern axises accel_buf[FIFO_MAX_PKG], gyro_buf[FIFO_MAX_PKG], g_out, a_out;
extern uint8_t temp_buf[FIFO_MAX_PKG];
extern uint16_t ts_buf[FIFO_MAX_PKG], pkt_cnt;
extern Calib_t gyro_offset,accel_offset;
extern volatile uint8_t idx,gyroIdx, startCalibration,startGyroCalib;
extern volatile int accelIdx;
extern float a_x,a_y,a_z,w_x,w_y,w_z;


HAL_StatusTypeDef ICM40609_Init(void);
HAL_StatusTypeDef icm40609_gyro_full_scale_select(gyro_full_scale full_scale);
HAL_StatusTypeDef icm40609_accel_full_scale_select(accel_full_scale full_scale);
HAL_StatusTypeDef icm40609_read_gyro(axises* data);
HAL_StatusTypeDef icm40609_read_accel(axises* data);
HAL_StatusTypeDef icm40609_read_accel_gyro(axises* accel, axises* gyro);
HAL_StatusTypeDef icm40609_read_all(axises* accel, axises* gyro, float* temperature);



HAL_StatusTypeDef ICM40609_CheckConection(void);
HAL_StatusTypeDef ICM40609_WriteRegister(uint8_t reg, uint8_t data);
HAL_StatusTypeDef ICM40609_ReadRegister(uint8_t ub,uint8_t reg,uint8_t len, uint8_t* pdata);
HAL_StatusTypeDef select_user_bank(userbank ub);
HAL_StatusTypeDef configuration(uint8_t ub, uint8_t reg_address, uint8_t value);


//ใช้งาน
//1
HAL_StatusTypeDef Accel6_CalibratePosition(uint16_t samples, uint8_t positionIndex, Calib_t *calib);
HAL_StatusTypeDef Accel6_ComputeCalibration(Calib_t *calib);
//2
HAL_StatusTypeDef ICM40609_CalibrateGyroOFFSET(uint16_t samples, Calib_t *gyro_bias);
//3
HAL_StatusTypeDef ICM40609_ReadFIFO_Packet3(axises*    accel_buf, axises*    gyro_buf, uint8_t*   temp_buf,uint16_t*  ts_buf, uint16_t   max_packets, uint16_t*  packet_count);

//6
HAL_StatusTypeDef calculate_rpy(axises* accel, axises* gyro, rpy_t* rpy, float dt);

//4
void Accel6_ApplyCalibration(
    const Calib_t *calib,
    const axises        *raw,     // .x/.y/.z คือค่าดิบ
    axises              *out      // .x/.y/.z คือค่าคาลิเบรต
);
//5
void Gyro_ApplyCalibration(
    const Calib_t     *calib,  // พารามิเตอร์ bias+scale
    const axises      *raw,    // ค่าดิบจาก FIFO (LSB)
    axises            *out     // ค่าชดเชยแล้ว (°/s)
);


float icm40609_read_temperature(void);



void RunIMUCalibration(void);//เรียกใช้การแคล accel gyro
void reset_cal(void);
void apply_icm40609(float *a_x, float *a_y, float *a_z, float *w_x, float *w_y, float *w_z); //ฟังก์ชั่นเรียกใช้อ่านค่าพร้อมแคล
void applyicm40609(axises *accel,axises *gyro);






#define RAD2DEG (180.0f / M_PI)
#define DEG2RAD   (M_PI / 180.0f)
#define GRAVITY 9.80665f



#define wm  64 //watermark fifo 4 samples(gyro accel temp timestamp) × 16 B = 64 bytes
#define WM_PACKETS   1

// Macros for FIFO registers and packet size
#define FIFO_COUNTH       0x2E    // FIFO byte count high :contentReference[oaicite:0]{index=0}:contentReference[oaicite:1]{index=1}
#define FIFO_COUNTL       0x2F    // FIFO byte count low  :contentReference[oaicite:2]{index=2}:contentReference[oaicite:3]{index=3}
#define FIFO_DATA         0x30    // FIFO data burst-read :contentReference[oaicite:4]{index=4}:contentReference[oaicite:5]{index=5}
#define FIFO_PACKET_SIZE  16      // Packet-3 size: Header+6 accel+6 gyro+2 ts+1 temp :contentReference[oaicite:6]{index=6}:contentReference[oaicite:7]{index=7}
#define FIFO_MAX_PACKETS  128     // max FIFO packets (128×16=2048B) :contentReference[oaicite:8]{index=8}:contentReference[oaicite:9]{index=9}


#define WM_BYTES     (WM_PACKETS * FIFO_PACKET_SIZE)
#define G_CONST    (1.0f)

#define I2C_HANDLE			(&hi2c2)
#define ICM40609_ADDRESS	0x69
#define WHO_AM_I_REG		0x75
#define PWR_MGMT0_REG		0x4E
#define READ  	0x80
#define WRITE 	0x00
#define MAX_RETRY_COUNT 3
#define GYRO_FS_MASK   0xE0
#define ACCEL_FS_MASK  0xE0


/*   filter low pass  */
// ---- Anti-Alias Filter ≈400 Hz ----
#define DESIRED_AAF_DELT     2    // 3 dB BW ≈400 Hz
#define DESIRED_AAF_DELTSQR  4   // square of delt
#define DESIRED_AAF_BITSHIFT 13     // bit-shift สำหรับ 400 Hz :contentReference[oaicite:0]{index=0}:contentReference[oaicite:1]{index=1}
// --- แยกเป็น Low/High nibble ---
#define DESIRED_AAF_DELTSQR_LOW   (DESIRED_AAF_DELTSQR & 0xFF)        // bits [7:0]  = 0x90  = 144
#define DESIRED_AAF_DELTSQR_HIGH  ((DESIRED_AAF_DELTSQR >> 8) & 0x0F) // bits [11:8] = 0x1   = 1

// ---- UI Filter: 1st-order, 3 dB BW ≈227 Hz ----
//GYRO_CONFIG1
#define DEFAULT_TEMP_FILT_BW 0
#define GYRO_UI_FILT_ORD     1    // 00 = 1st order :contentReference[oaicite:2]{index=2}:contentReference[oaicite:3]{index=3}
#define GYRO_DEC2_M2_ORD	 2

//GYRO_ACCEL_CONFIG0
#define GYRO_UI_FILT_BW      2    // 3 dB ≈227 Hz, NBW≈227 Hz, group delay ≈1.8 ms :contentReference[oaicite:4]{index=4}:contentReference[oaicite:5]{index=5}
#define ACCEL_UI_FILT_BW	 2

//ACCEL_CONFIG1
#define ACCEL_UI_FILT_ORD	1
#define ACCEL_DEC2_M2_ORD	2

/*   filter high pass  */

// สมมติว่าอยากใช้ 1st-order HPF ที่ ~5 Hz cutoff:
#define GYRO_NF_BW_SEL 		0
#define GYRO_HPF_BW_IND     1     // ตามตารางใน section 5.6, 1 → ≈5 Hz
#define GYRO_HPF_ORD_IND	0     // 0 → 1st order



/* USER BANK 0 */

/* reg_ADDRESS*/

#define DEVICE_CONFIG  	0x11
#define DRIVE_CONFIG   	0x13
#define INT_CONFIG		0x14
#define FIFO_CONFIG		0x16
#define TEMP_DATA1		0x1D
#define TEMP_DATA0		0x1E
#define ACCEL_DATA_X1	0x1F
#define ACCEL_DATA_X0	0x20
#define ACCEL_DATA_Y1	0x21
#define ACCEL_DATA_Y0	0x22
#define ACCEL_DATA_Z1	0x23
#define ACCEL_DATA_Z0	0x24
#define GYRO_DATA_X1	0x25
#define GYRO_DATA_X0	0x26
#define GYRO_DATA_Y1	0x27
#define GYRO_DATA_Y0	0x28
#define GYRO_DATA_Z1	0x29
#define GYRO_DATA_Z0	0x2A
#define TMST_FSYNCH		0x2B
#define TMST_FSYNCL		0x2C
#define INT_STATUS		0x2D
#define FIFO_COUNTH		0x2E
#define FIFO_COUNTL		0x2F
#define FIFO_DATA		0x30
#define INT_STATUS2		0x37
#define SIGNAL_PART_RESET	0x4B
#define INTF_CONFIG0	0x4C
#define INTF_CONFIG1	0x4D
#define PWR_MGMT0		0x4E
#define GYRO_CONFIG0	0x4F
#define ACCEL_CONFIG0	0x50
#define GYRO_CONFIG1	0x51
#define GYRO_ACCEL_CONFIG0	0x52
#define ACCEL_CONFIG1	0x53
#define TMST_CONFIG		0x54
#define WOM_CONFIG		0x57
#define FIFO_CONFIG1	0x5F
#define FIFO_CONFIG2	0x60
#define FIFO_CONFIG3	0x61
#define FSYNC_CONFIG	0x62
#define INT_CONFIG0		0x63
#define INT_CONFIG1		0x64
#define INT_SOURCE0		0x65
#define INT_SOURCE1		0x66
#define INT_SOURCE3		0x68
#define INT_SOURCE4		0x69
#define FIFO_LOST_PKT0	0x6C
#define FIFO_LOST_PKT1	0x6D
#define SELF_TEST_CONFIG	0x70
#define WHO_AM_I		0x75
#define REG_BANK_SEL	0x76


/* USER BANK 1*/
// reg_ADDRESS

#define SENSOR_CONFIG0			0x03
#define GYRO_CONFIG_STATIC2		0x0B
#define GYRO_CONFIG_STATIC3		0x0C
#define GYRO_CONFIG_STATIC4		0x0D
#define GYRO_CONFIG_STATIC5		0x0E
#define GYRO_CONFIG_STATIC6		0x0F
#define GYRO_CONFIG_STATIC7		0x10
#define GYRO_CONFIG_STATIC8		0x11
#define GYRO_CONFIG_STATIC9		0x12
#define GYRO_CONFIG_STATIC10	0x13
#define XG_ST_DATA				0x5F
#define YG_ST_DATA				0x60
#define ZG_ST_DATA				0x61
#define TMSTVAL0				0x62
#define TMSTVAL1				0x63
#define TMSTVAL2				0x64
#define INTF_CONFIG4			0x7A
#define INTF_CONFIG5			0x7B


/* USER BANK 2 */
//reg_ADDRESS

#define ACCEL_CONFIG_STATIC2	0x03
#define	ACCEL_CONFIG_STATIC3	0x04
#define ACCEL_CONFIG_STATIC4	0x05
#define XA_ST_DATA				0x3B
#define YA_ST_DATA				0x3C
#define ZA_ST_DATA				0x3D


/* USER BANK 4 */
//reg_ADDRESS

#define ACCEL_WOM_X_THR 0x4A
#define ACCEL_WOM_Y_THR	0x4B
#define ACCEL_WOM_Z_THR	0x4C
#define OFFSET_USER0	0x77
#define OFFSET_USER1	0x78
#define OFFSET_USER2 	0x79
#define OFFSET_USER3	0x7A
#define OFFSET_USER4	0x7B
#define OFFSET_USER5	0x7C
#define OFFSET_USER6 	0x7D
#define OFFSET_USER7	0x7E
#define OFFSET_USER8	0x7F

//value
//BANK0
#define PWR_MGMT0_VALUE 	0x0F
#define DEVICE_RESET		0x01
#define DRIVE_DEFAUL		0x2D
#define GYRO_CONFIG0_VALUE 	0x01
#define ACCEL_CONFIG0_VALUE	0x01
#define FIFO_CONFIG_VALUE	0x40
#define FIFO_CONFIG1_VALUE	0x6F
#define FIFO_CONFIG2_VALUE	0x00
#define FIFO_CONFIG3_VALUE	0x08 //2048 byte
#define INT_CONFIG_VALUE	0x07
#define INT_SOURCE0_VALUE	0x10
#define SIGNAL_PART_RESET_VALUE	0x02
#define INTF_CONFIG0_VALUE	0xC0
#define INTF_CONFIG0_RC_MODE 0xF0

//BANK1
#define SENSER_CONFIG0_GYRO 0x00


#endif /* INC_SENSOR_H_ */
